Grailbird.data.tweets_2012_06 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Trey Patrick",
      "screen_name" : "Treyskie",
      "indices" : [ 0, 9 ],
      "id_str" : "332641659",
      "id" : 332641659
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "219186862735106048",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 41.9770997957, -87.8983566565 ]
  },
  "id_str" : "219208926246354944",
  "in_reply_to_user_id" : 332641659,
  "text" : "@Treyskie I was thinking Daycon but anything in general too. Keep me in the loop",
  "id" : 219208926246354944,
  "in_reply_to_status_id" : 219186862735106048,
  "created_at" : "2012-06-30 23:20:55 +0000",
  "in_reply_to_screen_name" : "Treyskie",
  "in_reply_to_user_id_str" : "332641659",
  "user" : {
    "name" : "Dibyo Mukherjee",
    "screen_name" : "Dibyo13",
    "protected" : false,
    "id_str" : "21480436",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2692919961\/0a7d701ca39a1c35ee6102255665dafd_normal.jpeg",
    "id" : 21480436,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jordan Thompson ",
      "screen_name" : "jthompson016",
      "indices" : [ 0, 13 ],
      "id_str" : "545392596",
      "id" : 545392596
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Thai",
      "indices" : [ 39, 44 ]
    }, {
      "text" : "gelato",
      "indices" : [ 81, 88 ]
    }, {
      "text" : "gelatohackers",
      "indices" : [ 89, 103 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "219197925467758593",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 41.9771045764, -87.8983298755 ]
  },
  "id_str" : "219208603276558336",
  "in_reply_to_user_id" : 545392596,
  "text" : "@jthompson016 thank you sir. Enjoy the #Thai and don't forget your daily dose of #gelato #gelatohackers",
  "id" : 219208603276558336,
  "in_reply_to_status_id" : 219197925467758593,
  "created_at" : "2012-06-30 23:19:38 +0000",
  "in_reply_to_screen_name" : "jthompson016",
  "in_reply_to_user_id_str" : "545392596",
  "user" : {
    "name" : "Dibyo Mukherjee",
    "screen_name" : "Dibyo13",
    "protected" : false,
    "id_str" : "21480436",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2692919961\/0a7d701ca39a1c35ee6102255665dafd_normal.jpeg",
    "id" : 21480436,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "EMK",
      "screen_name" : "FaithKaram",
      "indices" : [ 0, 11 ],
      "id_str" : "447090890",
      "id" : 447090890
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "219204315015938049",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 41.9771307548, -87.8983783839 ]
  },
  "id_str" : "219207645544972289",
  "in_reply_to_user_id" : 447090890,
  "text" : "@FaithKaram you bet I will",
  "id" : 219207645544972289,
  "in_reply_to_status_id" : 219204315015938049,
  "created_at" : "2012-06-30 23:15:50 +0000",
  "in_reply_to_screen_name" : "FaithKaram",
  "in_reply_to_user_id_str" : "447090890",
  "user" : {
    "name" : "Dibyo Mukherjee",
    "screen_name" : "Dibyo13",
    "protected" : false,
    "id_str" : "21480436",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2692919961\/0a7d701ca39a1c35ee6102255665dafd_normal.jpeg",
    "id" : 21480436,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "219185811751583744",
  "text" : "Chicago O'Hare needs free wifi",
  "id" : 219185811751583744,
  "created_at" : "2012-06-30 21:49:04 +0000",
  "user" : {
    "name" : "Dibyo Mukherjee",
    "screen_name" : "Dibyo13",
    "protected" : false,
    "id_str" : "21480436",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2692919961\/0a7d701ca39a1c35ee6102255665dafd_normal.jpeg",
    "id" : 21480436,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Trey Patrick",
      "screen_name" : "Treyskie",
      "indices" : [ 0, 9 ],
      "id_str" : "332641659",
      "id" : 332641659
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Sismat",
      "indices" : [ 38, 45 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "219103146587328513",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 41.9770371067, -87.8980587874 ]
  },
  "id_str" : "219185626719850496",
  "in_reply_to_user_id" : 332641659,
  "text" : "@Treyskie yes sir. Let's try to get a #Sismat ctf team up...",
  "id" : 219185626719850496,
  "in_reply_to_status_id" : 219103146587328513,
  "created_at" : "2012-06-30 21:48:20 +0000",
  "in_reply_to_screen_name" : "Treyskie",
  "in_reply_to_user_id_str" : "332641659",
  "user" : {
    "name" : "Dibyo Mukherjee",
    "screen_name" : "Dibyo13",
    "protected" : false,
    "id_str" : "21480436",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2692919961\/0a7d701ca39a1c35ee6102255665dafd_normal.jpeg",
    "id" : 21480436,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "EMK",
      "screen_name" : "FaithKaram",
      "indices" : [ 0, 11 ],
      "id_str" : "447090890",
      "id" : 447090890
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "219123344635736065",
  "geo" : { },
  "id_str" : "219185402400092160",
  "in_reply_to_user_id" : 447090890,
  "text" : "@FaithKaram you too. Keep instragramming!!!",
  "id" : 219185402400092160,
  "in_reply_to_status_id" : 219123344635736065,
  "created_at" : "2012-06-30 21:47:26 +0000",
  "in_reply_to_screen_name" : "FaithKaram",
  "in_reply_to_user_id_str" : "447090890",
  "user" : {
    "name" : "Dibyo Mukherjee",
    "screen_name" : "Dibyo13",
    "protected" : false,
    "id_str" : "21480436",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2692919961\/0a7d701ca39a1c35ee6102255665dafd_normal.jpeg",
    "id" : 21480436,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Trey Patrick",
      "screen_name" : "Treyskie",
      "indices" : [ 0, 9 ],
      "id_str" : "332641659",
      "id" : 332641659
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "HackerHacker",
      "indices" : [ 65, 78 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "219086037346037760",
  "geo" : { },
  "id_str" : "219102041434361857",
  "in_reply_to_user_id" : 332641659,
  "text" : "@Treyskie Different terminals then, I think...have a safe flight #HackerHacker",
  "id" : 219102041434361857,
  "in_reply_to_status_id" : 219086037346037760,
  "created_at" : "2012-06-30 16:16:12 +0000",
  "in_reply_to_screen_name" : "Treyskie",
  "in_reply_to_user_id_str" : "332641659",
  "user" : {
    "name" : "Dibyo Mukherjee",
    "screen_name" : "Dibyo13",
    "protected" : false,
    "id_str" : "21480436",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2692919961\/0a7d701ca39a1c35ee6102255665dafd_normal.jpeg",
    "id" : 21480436,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Trey Patrick",
      "screen_name" : "Treyskie",
      "indices" : [ 0, 9 ],
      "id_str" : "332641659",
      "id" : 332641659
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "219053502813585413",
  "geo" : { },
  "id_str" : "219072084935061507",
  "in_reply_to_user_id" : 332641659,
  "text" : "@Treyskie  what terminal are you going to be in? And when is your flight?",
  "id" : 219072084935061507,
  "in_reply_to_status_id" : 219053502813585413,
  "created_at" : "2012-06-30 14:17:09 +0000",
  "in_reply_to_screen_name" : "Treyskie",
  "in_reply_to_user_id_str" : "332641659",
  "user" : {
    "name" : "Dibyo Mukherjee",
    "screen_name" : "Dibyo13",
    "protected" : false,
    "id_str" : "21480436",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2692919961\/0a7d701ca39a1c35ee6102255665dafd_normal.jpeg",
    "id" : 21480436,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael E. Locasto",
      "screen_name" : "mlocasto",
      "indices" : [ 12, 21 ],
      "id_str" : "148872500",
      "id" : 148872500
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 43.7047392894, -72.2867457384 ]
  },
  "id_str" : "218855518347853824",
  "text" : "gelato time @mlocasto ?",
  "id" : 218855518347853824,
  "created_at" : "2012-06-29 23:56:36 +0000",
  "user" : {
    "name" : "Dibyo Mukherjee",
    "screen_name" : "Dibyo13",
    "protected" : false,
    "id_str" : "21480436",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2692919961\/0a7d701ca39a1c35ee6102255665dafd_normal.jpeg",
    "id" : 21480436,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SISMAT2012",
      "indices" : [ 0, 11 ]
    } ],
    "urls" : [ {
      "indices" : [ 18, 38 ],
      "url" : "http:\/\/t.co\/C0qSAvEd",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=IZYQILfxHiw",
      "display_url" : "youtube.com\/watch?v=IZYQIL\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "217068959277649922",
  "text" : "#SISMAT2012 theme http:\/\/t.co\/C0qSAvEd",
  "id" : 217068959277649922,
  "created_at" : "2012-06-25 01:37:27 +0000",
  "user" : {
    "name" : "Dibyo Mukherjee",
    "screen_name" : "Dibyo13",
    "protected" : false,
    "id_str" : "21480436",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2692919961\/0a7d701ca39a1c35ee6102255665dafd_normal.jpeg",
    "id" : 21480436,
    "verified" : false
  }
} ]