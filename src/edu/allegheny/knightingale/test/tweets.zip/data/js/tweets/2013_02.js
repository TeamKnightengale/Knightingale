Grailbird.data.tweets_2013_02 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/tweetbutton\" rel=\"nofollow\"\u003ETweet Button\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "MakeUseOf",
      "screen_name" : "MakeUseOf",
      "indices" : [ 60, 70 ],
      "id_str" : "63043",
      "id" : 63043
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "giveaway",
      "indices" : [ 47, 56 ]
    } ],
    "urls" : [ {
      "indices" : [ 82, 104 ],
      "url" : "http:\/\/t.co\/mqkIb0nNJ1",
      "expanded_url" : "http:\/\/www.makeuseof.com\/tag\/pdfstacks-managing-reading-and-searching-your-pdfs-made-easy-giveaway\/",
      "display_url" : "makeuseof.com\/tag\/pdfstacks-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "306208905200025600",
  "text" : "Manage your PDFs the right way with PDF Stacks #giveaway at @makeuseof. Join now! http:\/\/t.co\/mqkIb0nNJ1",
  "id" : 306208905200025600,
  "created_at" : "2013-02-26 01:07:46 +0000",
  "user" : {
    "name" : "Dibyo Mukherjee",
    "screen_name" : "Dibyo13",
    "protected" : false,
    "id_str" : "21480436",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2692919961\/0a7d701ca39a1c35ee6102255665dafd_normal.jpeg",
    "id" : 21480436,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gregory Kapfhammer",
      "screen_name" : "GregKapfhammer",
      "indices" : [ 3, 18 ],
      "id_str" : "361673478",
      "id" : 361673478
    }, {
      "name" : "Allegheny College",
      "screen_name" : "alleghenycol",
      "indices" : [ 58, 71 ],
      "id_str" : "5865752",
      "id" : 5865752
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "299986754834944000",
  "text" : "RT @GregKapfhammer: The Department of Computer Science at @alleghenycol is hiring a tenure-track assistant professor! Share and apply: h ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/launchpad.net\/polly\" rel=\"nofollow\"\u003EPolly\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Allegheny College",
        "screen_name" : "alleghenycol",
        "indices" : [ 38, 51 ],
        "id_str" : "5865752",
        "id" : 5865752
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 115, 135 ],
        "url" : "http:\/\/t.co\/j4x5SvrB",
        "expanded_url" : "http:\/\/is.gd\/F4TwSU",
        "display_url" : "is.gd\/F4TwSU"
      } ]
    },
    "geo" : { },
    "id_str" : "299597798914007042",
    "text" : "The Department of Computer Science at @alleghenycol is hiring a tenure-track assistant professor! Share and apply: http:\/\/t.co\/j4x5SvrB",
    "id" : 299597798914007042,
    "created_at" : "2013-02-07 19:17:36 +0000",
    "user" : {
      "name" : "Gregory Kapfhammer",
      "screen_name" : "GregKapfhammer",
      "protected" : false,
      "id_str" : "361673478",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2284981120\/wan4u9fthmpvgug9khsc_normal.jpeg",
      "id" : 361673478,
      "verified" : false
    }
  },
  "id" : 299986754834944000,
  "created_at" : "2013-02-08 21:03:10 +0000",
  "user" : {
    "name" : "Dibyo Mukherjee",
    "screen_name" : "Dibyo13",
    "protected" : false,
    "id_str" : "21480436",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2692919961\/0a7d701ca39a1c35ee6102255665dafd_normal.jpeg",
    "id" : 21480436,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Greatbong",
      "screen_name" : "greatbong",
      "indices" : [ 3, 13 ],
      "id_str" : "18745932",
      "id" : 18745932
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "298312705260003329",
  "text" : "RT @greatbong: 49-ers. A good name for the youth wing of an Indian political party.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "298240033490608129",
    "text" : "49-ers. A good name for the youth wing of an Indian political party.",
    "id" : 298240033490608129,
    "created_at" : "2013-02-04 01:22:19 +0000",
    "user" : {
      "name" : "Greatbong",
      "screen_name" : "greatbong",
      "protected" : false,
      "id_str" : "18745932",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000739842510\/473b0cc9a89721e0542e48350ad02e92_normal.jpeg",
      "id" : 18745932,
      "verified" : false
    }
  },
  "id" : 298312705260003329,
  "created_at" : "2013-02-04 06:11:05 +0000",
  "user" : {
    "name" : "Dibyo Mukherjee",
    "screen_name" : "Dibyo13",
    "protected" : false,
    "id_str" : "21480436",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2692919961\/0a7d701ca39a1c35ee6102255665dafd_normal.jpeg",
    "id" : 21480436,
    "verified" : false
  }
} ]