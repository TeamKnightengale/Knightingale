Grailbird.data.tweets_2012_12 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chetan Bhagat",
      "screen_name" : "chetan_bhagat",
      "indices" : [ 3, 17 ],
      "id_str" : "44588485",
      "id" : 44588485
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "282939211886260224",
  "text" : "RT @chetan_bhagat: A sexually repressed population and a culture of power abuse, what happened in Delhi was the worst of these aspects i ...",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "281446344655241216",
    "text" : "A sexually repressed population and a culture of power abuse, what happened in Delhi was the worst of these aspects in our society.",
    "id" : 281446344655241216,
    "created_at" : "2012-12-19 17:10:12 +0000",
    "user" : {
      "name" : "Chetan Bhagat",
      "screen_name" : "chetan_bhagat",
      "protected" : false,
      "id_str" : "44588485",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3291106775\/366fcdbc011a8383610e6973d22cc884_normal.jpeg",
      "id" : 44588485,
      "verified" : true
    }
  },
  "id" : 282939211886260224,
  "created_at" : "2012-12-23 20:02:19 +0000",
  "user" : {
    "name" : "Dibyo Mukherjee",
    "screen_name" : "Dibyo13",
    "protected" : false,
    "id_str" : "21480436",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2692919961\/0a7d701ca39a1c35ee6102255665dafd_normal.jpeg",
    "id" : 21480436,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/tweetbutton\" rel=\"nofollow\"\u003ETweet Button\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "LaunchSky",
      "screen_name" : "LaunchSky",
      "indices" : [ 106, 116 ],
      "id_str" : "987959923",
      "id" : 987959923
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 137 ],
      "url" : "http:\/\/t.co\/Kz12RcI1",
      "expanded_url" : "http:\/\/launchsky.com",
      "display_url" : "launchsky.com"
    } ]
  },
  "geo" : { },
  "id_str" : "276451630537375744",
  "text" : "Stop building apps no one wants. Pitch your idea in minutes. Be the first to adopt awesome new ideas. via @LaunchSky http:\/\/t.co\/Kz12RcI1",
  "id" : 276451630537375744,
  "created_at" : "2012-12-05 22:22:59 +0000",
  "user" : {
    "name" : "Dibyo Mukherjee",
    "screen_name" : "Dibyo13",
    "protected" : false,
    "id_str" : "21480436",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2692919961\/0a7d701ca39a1c35ee6102255665dafd_normal.jpeg",
    "id" : 21480436,
    "verified" : false
  }
} ]