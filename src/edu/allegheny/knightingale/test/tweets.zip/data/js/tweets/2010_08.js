Grailbird.data.tweets_2010_08 = 
 [ {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Suresh Nair",
      "screen_name" : "Nair_Suresh",
      "indices" : [ 3, 15 ],
      "id_str" : "66612094",
      "id" : 66612094
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "21799054557",
  "text" : "RT @Nair_Suresh: If our members of parliament can decide to give themselves 300% salary hike, can their voters decide to not pay 100% in ...",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "21724775972",
    "text" : "If our members of parliament can decide to give themselves 300% salary hike, can their voters decide to not pay 100% income tax?",
    "id" : 21724775972,
    "created_at" : "2010-08-21 05:09:26 +0000",
    "user" : {
      "name" : "Suresh Nair",
      "screen_name" : "Nair_Suresh",
      "protected" : false,
      "id_str" : "66612094",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/374066471\/MBG_SURESH_NAIR_001__normal.jpg",
      "id" : 66612094,
      "verified" : false
    }
  },
  "id" : 21799054557,
  "created_at" : "2010-08-22 00:00:00 +0000",
  "user" : {
    "name" : "Dibyo Mukherjee",
    "screen_name" : "Dibyo13",
    "protected" : false,
    "id_str" : "21480436",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2692919961\/0a7d701ca39a1c35ee6102255665dafd_normal.jpeg",
    "id" : 21480436,
    "verified" : false
  }
} ]