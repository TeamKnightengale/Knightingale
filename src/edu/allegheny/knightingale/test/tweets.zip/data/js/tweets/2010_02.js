Grailbird.data.tweets_2010_02 = 
 [ {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "9668693706",
  "text" : "Getting ready for the big B's.......",
  "id" : 9668693706,
  "created_at" : "2010-02-26 00:00:00 +0000",
  "user" : {
    "name" : "Dibyo Mukherjee",
    "screen_name" : "Dibyo13",
    "protected" : false,
    "id_str" : "21480436",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2692919961\/0a7d701ca39a1c35ee6102255665dafd_normal.jpeg",
    "id" : 21480436,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SHAH RUKH KHAN",
      "screen_name" : "iamsrk",
      "indices" : [ 3, 10 ],
      "id_str" : "101311381",
      "id" : 101311381
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "9668743613",
  "text" : "RT @iamsrk: alright all studing to be doctors, engineers, architects,businessmen..and all professions...hope u all get ur dreams fulfilled.",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "9651095894",
    "text" : "alright all studing to be doctors, engineers, architects,businessmen..and all professions...hope u all get ur dreams fulfilled.",
    "id" : 9651095894,
    "created_at" : "2010-02-26 00:21:36 +0000",
    "user" : {
      "name" : "SHAH RUKH KHAN",
      "screen_name" : "iamsrk",
      "protected" : false,
      "id_str" : "101311381",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/661679664\/keep_it_onn_normal.jpg",
      "id" : 101311381,
      "verified" : true
    }
  },
  "id" : 9668743613,
  "created_at" : "2010-02-26 00:00:00 +0000",
  "user" : {
    "name" : "Dibyo Mukherjee",
    "screen_name" : "Dibyo13",
    "protected" : false,
    "id_str" : "21480436",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2692919961\/0a7d701ca39a1c35ee6102255665dafd_normal.jpeg",
    "id" : 21480436,
    "verified" : false
  }
} ]