Grailbird.data.tweets_2011_11 = 
 [ {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adorama ",
      "screen_name" : "adorama",
      "indices" : [ 51, 59 ],
      "id_str" : "14287474",
      "id" : 14287474
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 98, 117 ],
      "url" : "http:\/\/t.co\/z3focy9",
      "expanded_url" : "http:\/\/goo.gl\/UNFw0",
      "display_url" : "goo.gl\/UNFw0"
    } ]
  },
  "geo" : { },
  "id_str" : "142066405930577921",
  "text" : "Enter to win a new Canon 5D MK II camera body from @Adorama and Scott Bourne. Please RT. Info at: http:\/\/t.co\/z3focy9",
  "id" : 142066405930577921,
  "created_at" : "2011-12-01 02:24:05 +0000",
  "user" : {
    "name" : "Dibyo Mukherjee",
    "screen_name" : "Dibyo13",
    "protected" : false,
    "id_str" : "21480436",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2692919961\/0a7d701ca39a1c35ee6102255665dafd_normal.jpeg",
    "id" : 21480436,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/tweetbutton\" rel=\"nofollow\"\u003ETweet Button\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 84, 92 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 60, 79 ],
      "url" : "http:\/\/t.co\/S82729w",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=8r1CZTLk-Gk&feature=share",
      "display_url" : "youtube.com\/watch?v=8r1CZT\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "134133862098944000",
  "text" : "Check this video out -- Everythings Amazing & Nobodys Happy http:\/\/t.co\/S82729w via @youtube",
  "id" : 134133862098944000,
  "created_at" : "2011-11-09 05:02:59 +0000",
  "user" : {
    "name" : "Dibyo Mukherjee",
    "screen_name" : "Dibyo13",
    "protected" : false,
    "id_str" : "21480436",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2692919961\/0a7d701ca39a1c35ee6102255665dafd_normal.jpeg",
    "id" : 21480436,
    "verified" : false
  }
} ]