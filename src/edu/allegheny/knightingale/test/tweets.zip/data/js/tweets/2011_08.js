Grailbird.data.tweets_2011_08 = 
 [ {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Farhan Akhtar",
      "screen_name" : "FarOutAkhtar",
      "indices" : [ 3, 16 ],
      "id_str" : "97865628",
      "id" : 97865628
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "100909639096467456",
  "text" : "RT @FarOutAkhtar: Discovered: Water on Mars and a smooth stretch of road in Mumbai. The latter was harder to find.",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "100908763317403650",
    "text" : "Discovered: Water on Mars and a smooth stretch of road in Mumbai. The latter was harder to find.",
    "id" : 100908763317403650,
    "created_at" : "2011-08-09 12:38:18 +0000",
    "user" : {
      "name" : "Farhan Akhtar",
      "screen_name" : "FarOutAkhtar",
      "protected" : false,
      "id_str" : "97865628",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3358855365\/7ff1d34c16708463327bde8964388b11_normal.jpeg",
      "id" : 97865628,
      "verified" : true
    }
  },
  "id" : 100909639096467456,
  "created_at" : "2011-08-09 12:41:47 +0000",
  "user" : {
    "name" : "Dibyo Mukherjee",
    "screen_name" : "Dibyo13",
    "protected" : false,
    "id_str" : "21480436",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2692919961\/0a7d701ca39a1c35ee6102255665dafd_normal.jpeg",
    "id" : 21480436,
    "verified" : false
  }
} ]