Grailbird.data.tweets_2013_05 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/tweetbutton\" rel=\"nofollow\"\u003ETweet Button\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Codementor",
      "screen_name" : "CodementorIO",
      "indices" : [ 88, 101 ],
      "id_str" : "1344064868",
      "id" : 1344064868
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 61, 83 ],
      "url" : "http:\/\/t.co\/71Xjmi4ZGu",
      "expanded_url" : "http:\/\/www.codementor.io\/?rid=270",
      "display_url" : "codementor.io\/?rid=270"
    } ]
  },
  "geo" : { },
  "id_str" : "340521713093713923",
  "text" : "Join codementor - instant 1-on-1 mentor for any code issues. http:\/\/t.co\/71Xjmi4ZGu via @CodementorIO",
  "id" : 340521713093713923,
  "created_at" : "2013-05-31 17:34:37 +0000",
  "user" : {
    "name" : "Dibyo Mukherjee",
    "screen_name" : "Dibyo13",
    "protected" : false,
    "id_str" : "21480436",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2692919961\/0a7d701ca39a1c35ee6102255665dafd_normal.jpeg",
    "id" : 21480436,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gregory Kapfhammer",
      "screen_name" : "GregKapfhammer",
      "indices" : [ 0, 15 ],
      "id_str" : "361673478",
      "id" : 361673478
    }, {
      "name" : "Jeff Siarto",
      "screen_name" : "jsiarto",
      "indices" : [ 102, 110 ],
      "id_str" : "3444311",
      "id" : 3444311
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 111, 134 ],
      "url" : "https:\/\/t.co\/eBsiLGJl4j",
      "expanded_url" : "https:\/\/medium.com\/education-today\/78dc8e3f66f1",
      "display_url" : "medium.com\/education-toda\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "338491344760733696",
  "in_reply_to_user_id" : 361673478,
  "text" : "@GregKapfhammer Reminds me of my group module presentation: \"Version Control and Higher Education\" by @jsiarto https:\/\/t.co\/eBsiLGJl4j",
  "id" : 338491344760733696,
  "created_at" : "2013-05-26 03:06:40 +0000",
  "in_reply_to_screen_name" : "GregKapfhammer",
  "in_reply_to_user_id_str" : "361673478",
  "user" : {
    "name" : "Dibyo Mukherjee",
    "screen_name" : "Dibyo13",
    "protected" : false,
    "id_str" : "21480436",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2692919961\/0a7d701ca39a1c35ee6102255665dafd_normal.jpeg",
    "id" : 21480436,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kyem Ghosh",
      "screen_name" : "KyemGhosh",
      "indices" : [ 0, 10 ],
      "id_str" : "141327338",
      "id" : 141327338
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "333092043465302018",
  "geo" : { },
  "id_str" : "333110574567264259",
  "in_reply_to_user_id" : 21480436,
  "text" : "@KyemGhosh  Tomar ki khobor?",
  "id" : 333110574567264259,
  "in_reply_to_status_id" : 333092043465302018,
  "created_at" : "2013-05-11 06:45:24 +0000",
  "in_reply_to_screen_name" : "Dibyo13",
  "in_reply_to_user_id_str" : "21480436",
  "user" : {
    "name" : "Dibyo Mukherjee",
    "screen_name" : "Dibyo13",
    "protected" : false,
    "id_str" : "21480436",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2692919961\/0a7d701ca39a1c35ee6102255665dafd_normal.jpeg",
    "id" : 21480436,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/tweetbutton\" rel=\"nofollow\"\u003ETweet Button\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kyem Ghosh",
      "screen_name" : "KyemGhosh",
      "indices" : [ 0, 10 ],
      "id_str" : "141327338",
      "id" : 141327338
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "333075358805020672",
  "geo" : { },
  "id_str" : "333092043465302018",
  "in_reply_to_user_id" : 141327338,
  "text" : "@KyemGhosh  Yes sir!",
  "id" : 333092043465302018,
  "in_reply_to_status_id" : 333075358805020672,
  "created_at" : "2013-05-11 05:31:46 +0000",
  "in_reply_to_screen_name" : "KyemGhosh",
  "in_reply_to_user_id_str" : "141327338",
  "user" : {
    "name" : "Dibyo Mukherjee",
    "screen_name" : "Dibyo13",
    "protected" : false,
    "id_str" : "21480436",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2692919961\/0a7d701ca39a1c35ee6102255665dafd_normal.jpeg",
    "id" : 21480436,
    "verified" : false
  }
} ]