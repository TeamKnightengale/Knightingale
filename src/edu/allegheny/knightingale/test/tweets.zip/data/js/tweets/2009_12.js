Grailbird.data.tweets_2009_12 = 
 [ {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NDTV Indian",
      "screen_name" : "NDTVIndian",
      "indices" : [ 3, 14 ],
      "id_str" : "93840660",
      "id" : 93840660
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "NDTVINDIAN",
      "indices" : [ 102, 113 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7268639295",
  "text" : "RT @NDTVIndian: My NDTV Indian of the Year 2009: P Chidambaram. Vote at http:\/\/twitter.com\/NDTVIndian #NDTVINDIAN",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "NDTVINDIAN",
        "indices" : [ 86, 97 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "6263812918",
    "text" : "My NDTV Indian of the Year 2009: P Chidambaram. Vote at http:\/\/twitter.com\/NDTVIndian #NDTVINDIAN",
    "id" : 6263812918,
    "created_at" : "2009-12-02 08:13:59 +0000",
    "user" : {
      "name" : "NDTV Indian",
      "screen_name" : "NDTVIndian",
      "protected" : false,
      "id_str" : "93840660",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/556667299\/IOY_09-social_normal.jpg",
      "id" : 93840660,
      "verified" : false
    }
  },
  "id" : 7268639295,
  "created_at" : "2010-01-01 00:00:00 +0000",
  "user" : {
    "name" : "Dibyo Mukherjee",
    "screen_name" : "Dibyo13",
    "protected" : false,
    "id_str" : "21480436",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2692919961\/0a7d701ca39a1c35ee6102255665dafd_normal.jpeg",
    "id" : 21480436,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "vir sanghvi",
      "screen_name" : "virsanghvi",
      "indices" : [ 3, 14 ],
      "id_str" : "43568964",
      "id" : 43568964
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7268696037",
  "text" : "RT @virsanghvi: I am on the side of Chetan Bhagat in the 3 Idiots controversy. Authors deserve prominent credit if their books are sources",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "7264465327",
    "text" : "I am on the side of Chetan Bhagat in the 3 Idiots controversy. Authors deserve prominent credit if their books are sources",
    "id" : 7264465327,
    "created_at" : "2010-01-01 08:19:16 +0000",
    "user" : {
      "name" : "vir sanghvi",
      "screen_name" : "virsanghvi",
      "protected" : false,
      "id_str" : "43568964",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000329353045\/a29991007d3cb5120961ace2b574076b_normal.jpeg",
      "id" : 43568964,
      "verified" : true
    }
  },
  "id" : 7268696037,
  "created_at" : "2010-01-01 00:00:00 +0000",
  "user" : {
    "name" : "Dibyo Mukherjee",
    "screen_name" : "Dibyo13",
    "protected" : false,
    "id_str" : "21480436",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2692919961\/0a7d701ca39a1c35ee6102255665dafd_normal.jpeg",
    "id" : 21480436,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "6398642204",
  "text" : "Pre boards freaking me out!!!!!",
  "id" : 6398642204,
  "created_at" : "2009-12-06 00:00:00 +0000",
  "user" : {
    "name" : "Dibyo Mukherjee",
    "screen_name" : "Dibyo13",
    "protected" : false,
    "id_str" : "21480436",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2692919961\/0a7d701ca39a1c35ee6102255665dafd_normal.jpeg",
    "id" : 21480436,
    "verified" : false
  }
} ]