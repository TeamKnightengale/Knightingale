Grailbird.data.tweets_2013_06 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/tweetbutton\" rel=\"nofollow\"\u003ETweet Button\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TicketWeb",
      "screen_name" : "TicketWeb",
      "indices" : [ 102, 112 ],
      "id_str" : "28594495",
      "id" : 28594495
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 75, 97 ],
      "url" : "http:\/\/t.co\/la8DbQrBfd",
      "expanded_url" : "http:\/\/www.ticketweb.com\/t3\/sale\/SaleEventDetail?dispatch=loadSelectionData&eventId=3651084&REFERRAL_ID=twtweet",
      "display_url" : "ticketweb.com\/t3\/sale\/SaleEv\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "350307104369803264",
  "text" : "Check out Ohio Independent Cinema Presents: On The North Coast @ Grog Shop http:\/\/t.co\/la8DbQrBfd via @ticketweb",
  "id" : 350307104369803264,
  "created_at" : "2013-06-27 17:38:16 +0000",
  "user" : {
    "name" : "Dibyo Mukherjee",
    "screen_name" : "Dibyo13",
    "protected" : false,
    "id_str" : "21480436",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2692919961\/0a7d701ca39a1c35ee6102255665dafd_normal.jpeg",
    "id" : 21480436,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NewRelic",
      "screen_name" : "newrelic",
      "indices" : [ 0, 9 ],
      "id_str" : "15527007",
      "id" : 15527007
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/Dibyo13\/status\/349882764402782208\/photo\/1",
      "indices" : [ 69, 91 ],
      "url" : "http:\/\/t.co\/iu4m64ueF0",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BNsIhT3CcAA_JEE.png",
      "id_str" : "349882764411170816",
      "id" : 349882764411170816,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BNsIhT3CcAA_JEE.png",
      "sizes" : [ {
        "h" : 455,
        "resize" : "fit",
        "w" : 374
      }, {
        "h" : 414,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 455,
        "resize" : "fit",
        "w" : 374
      }, {
        "h" : 455,
        "resize" : "fit",
        "w" : 374
      } ],
      "display_url" : "pic.twitter.com\/iu4m64ueF0"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "349882764402782208",
  "in_reply_to_user_id" : 15527007,
  "text" : "@newrelic can't see the options to choose from on the signup page :( http:\/\/t.co\/iu4m64ueF0",
  "id" : 349882764402782208,
  "created_at" : "2013-06-26 13:32:06 +0000",
  "in_reply_to_screen_name" : "newrelic",
  "in_reply_to_user_id_str" : "15527007",
  "user" : {
    "name" : "Dibyo Mukherjee",
    "screen_name" : "Dibyo13",
    "protected" : false,
    "id_str" : "21480436",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2692919961\/0a7d701ca39a1c35ee6102255665dafd_normal.jpeg",
    "id" : 21480436,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "barkha dutt",
      "screen_name" : "BDUTT",
      "indices" : [ 3, 9 ],
      "id_str" : "19929890",
      "id" : 19929890
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "342269194294935552",
  "text" : "RT @BDUTT: Overheard:India back in the 90s. GDP 5%, Dalmiya heads BCCI, Murthy in charge of infy, Sanjay Dutt in Jail. Phaneesh charged wit\u2026",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "342267462714277889",
    "text" : "Overheard:India back in the 90s. GDP 5%, Dalmiya heads BCCI, Murthy in charge of infy, Sanjay Dutt in Jail. Phaneesh charged with harassment",
    "id" : 342267462714277889,
    "created_at" : "2013-06-05 13:11:36 +0000",
    "user" : {
      "name" : "barkha dutt",
      "screen_name" : "BDUTT",
      "protected" : false,
      "id_str" : "19929890",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2338940318\/ydjwvncjdyuthipa7v15_normal.jpeg",
      "id" : 19929890,
      "verified" : true
    }
  },
  "id" : 342269194294935552,
  "created_at" : "2013-06-05 13:18:29 +0000",
  "user" : {
    "name" : "Dibyo Mukherjee",
    "screen_name" : "Dibyo13",
    "protected" : false,
    "id_str" : "21480436",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2692919961\/0a7d701ca39a1c35ee6102255665dafd_normal.jpeg",
    "id" : 21480436,
    "verified" : false
  }
} ]