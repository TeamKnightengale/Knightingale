Grailbird.data.tweets_2010_05 = 
 [ {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amitabh Bachchan",
      "screen_name" : "SrBachchan",
      "indices" : [ 3, 14 ],
      "id_str" : "145125358",
      "id" : 145125358
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "14563312859",
  "text" : "RT @SrBachchan: T5 - When a true genius appears in the world, you may know him by this sign, that the dunces are all in confederacy agai ...",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "14508597779",
    "text" : "T5 - When a true genius appears in the world, you may know him by this sign, that the dunces are all in confederacy against him ..",
    "id" : 14508597779,
    "created_at" : "2010-05-22 18:13:18 +0000",
    "user" : {
      "name" : "Amitabh Bachchan",
      "screen_name" : "SrBachchan",
      "protected" : false,
      "id_str" : "145125358",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2227330575\/Amitji_normal.png",
      "id" : 145125358,
      "verified" : true
    }
  },
  "id" : 14563312859,
  "created_at" : "2010-05-23 00:00:00 +0000",
  "user" : {
    "name" : "Dibyo Mukherjee",
    "screen_name" : "Dibyo13",
    "protected" : false,
    "id_str" : "21480436",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2692919961\/0a7d701ca39a1c35ee6102255665dafd_normal.jpeg",
    "id" : 21480436,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Abhishek Bachchan",
      "screen_name" : "juniorbachchan",
      "indices" : [ 3, 18 ],
      "id_str" : "87170183",
      "id" : 87170183
    }, {
      "name" : "Dhaval Jogia",
      "screen_name" : "Dhaval6",
      "indices" : [ 32, 40 ],
      "id_str" : "144555624",
      "id" : 144555624
    }, {
      "name" : "Abhishek Bachchan",
      "screen_name" : "juniorbachchan",
      "indices" : [ 42, 57 ],
      "id_str" : "87170183",
      "id" : 87170183
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "14308779023",
  "text" : "RT @juniorbachchan: Nice one RT @Dhaval6: @juniorbachchan Great spirits have always encountered violent opposition from mediocre minds.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/ubertwitter.com\" rel=\"nofollow\"\u003EUberTwitter\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Dhaval Jogia",
        "screen_name" : "Dhaval6",
        "indices" : [ 12, 20 ],
        "id_str" : "144555624",
        "id" : 144555624
      }, {
        "name" : "Abhishek Bachchan",
        "screen_name" : "juniorbachchan",
        "indices" : [ 22, 37 ],
        "id_str" : "87170183",
        "id" : 87170183
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "14297190631",
    "text" : "Nice one RT @Dhaval6: @juniorbachchan Great spirits have always encountered violent opposition from mediocre minds.",
    "id" : 14297190631,
    "created_at" : "2010-05-19 14:06:54 +0000",
    "user" : {
      "name" : "Abhishek Bachchan",
      "screen_name" : "juniorbachchan",
      "protected" : false,
      "id_str" : "87170183",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1857345555\/image_normal.jpg",
      "id" : 87170183,
      "verified" : true
    }
  },
  "id" : 14308779023,
  "created_at" : "2010-05-19 00:00:00 +0000",
  "user" : {
    "name" : "Dibyo Mukherjee",
    "screen_name" : "Dibyo13",
    "protected" : false,
    "id_str" : "21480436",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2692919961\/0a7d701ca39a1c35ee6102255665dafd_normal.jpeg",
    "id" : 21480436,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Satchit Bhogle",
      "screen_name" : "RagingIndian",
      "indices" : [ 3, 16 ],
      "id_str" : "30214852",
      "id" : 30214852
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "14018377510",
  "text" : "RT @RagingIndian: Pietersen, Morgan, Lumb, Kieswetter: England's batting power is less through strong domestic industry and more through ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "wt20",
        "indices" : [ 135, 140 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "13995002383",
    "text" : "Pietersen, Morgan, Lumb, Kieswetter: England's batting power is less through strong domestic industry and more through low import duty #wt20",
    "id" : 13995002383,
    "created_at" : "2010-05-14 20:09:55 +0000",
    "user" : {
      "name" : "Satchit Bhogle",
      "screen_name" : "RagingIndian",
      "protected" : false,
      "id_str" : "30214852",
      "profile_image_url_https" : "https:\/\/abs.twimg.com\/sticky\/default_profile_images\/default_profile_3_normal.png",
      "id" : 30214852,
      "verified" : false
    }
  },
  "id" : 14018377510,
  "created_at" : "2010-05-15 00:00:00 +0000",
  "user" : {
    "name" : "Dibyo Mukherjee",
    "screen_name" : "Dibyo13",
    "protected" : false,
    "id_str" : "21480436",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2692919961\/0a7d701ca39a1c35ee6102255665dafd_normal.jpeg",
    "id" : 21480436,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mahesh Bhatt",
      "screen_name" : "MaheshNBhatt",
      "indices" : [ 3, 16 ],
      "id_str" : "53556894",
      "id" : 53556894
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "13906134621",
  "text" : "RT @MaheshNBhatt: A sign of celebrity is that his name is often worth more than his services.",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "13887126717",
    "text" : "A sign of celebrity is that his name is often worth more than his services.",
    "id" : 13887126717,
    "created_at" : "2010-05-13 02:09:22 +0000",
    "user" : {
      "name" : "Mahesh Bhatt",
      "screen_name" : "MaheshNBhatt",
      "protected" : false,
      "id_str" : "53556894",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3299211056\/23e12b7aaf488f094f3180e6603fe058_normal.jpeg",
      "id" : 53556894,
      "verified" : true
    }
  },
  "id" : 13906134621,
  "created_at" : "2010-05-13 00:00:00 +0000",
  "user" : {
    "name" : "Dibyo Mukherjee",
    "screen_name" : "Dibyo13",
    "protected" : false,
    "id_str" : "21480436",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2692919961\/0a7d701ca39a1c35ee6102255665dafd_normal.jpeg",
    "id" : 21480436,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Funny One Liners",
      "screen_name" : "funnyoneliners",
      "indices" : [ 3, 18 ],
      "id_str" : "40885516",
      "id" : 40885516
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "13906168002",
  "text" : "RT @funnyoneliners: Never let a fool kiss you. Or a kiss fool you.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/birdhouseapp.com\" rel=\"nofollow\"\u003EBirdhouse\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "13759030469",
    "text" : "Never let a fool kiss you. Or a kiss fool you.",
    "id" : 13759030469,
    "created_at" : "2010-05-11 00:58:40 +0000",
    "user" : {
      "name" : "Funny One Liners",
      "screen_name" : "funnyoneliners",
      "protected" : false,
      "id_str" : "40885516",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/217287898\/051809_189_normal.JPG",
      "id" : 40885516,
      "verified" : false
    }
  },
  "id" : 13906168002,
  "created_at" : "2010-05-13 00:00:00 +0000",
  "user" : {
    "name" : "Dibyo Mukherjee",
    "screen_name" : "Dibyo13",
    "protected" : false,
    "id_str" : "21480436",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2692919961\/0a7d701ca39a1c35ee6102255665dafd_normal.jpeg",
    "id" : 21480436,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "barkha dutt",
      "screen_name" : "BDUTT",
      "indices" : [ 3, 9 ],
      "id_str" : "19929890",
      "id" : 19929890
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "13661898196",
  "text" : "RT @BDUTT: http:\/\/tinyurl.com\/2gykb6o best piece ive read yet on Shahzad, now dubbed the idiot bomber.",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "13626923353",
    "text" : "http:\/\/tinyurl.com\/2gykb6o best piece ive read yet on Shahzad, now dubbed the idiot bomber.",
    "id" : 13626923353,
    "created_at" : "2010-05-08 20:14:53 +0000",
    "user" : {
      "name" : "barkha dutt",
      "screen_name" : "BDUTT",
      "protected" : false,
      "id_str" : "19929890",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2338940318\/ydjwvncjdyuthipa7v15_normal.jpeg",
      "id" : 19929890,
      "verified" : true
    }
  },
  "id" : 13661898196,
  "created_at" : "2010-05-09 00:00:00 +0000",
  "user" : {
    "name" : "Dibyo Mukherjee",
    "screen_name" : "Dibyo13",
    "protected" : false,
    "id_str" : "21480436",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2692919961\/0a7d701ca39a1c35ee6102255665dafd_normal.jpeg",
    "id" : 21480436,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kyem Ghosh",
      "screen_name" : "KyemGhosh",
      "indices" : [ 0, 10 ],
      "id_str" : "141327338",
      "id" : 141327338
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "13661996947",
  "in_reply_to_user_id" : 141327338,
  "text" : "@KyemGhosh Welcome!!!!!",
  "id" : 13661996947,
  "created_at" : "2010-05-09 00:00:00 +0000",
  "in_reply_to_screen_name" : "KyemGhosh",
  "in_reply_to_user_id_str" : "141327338",
  "user" : {
    "name" : "Dibyo Mukherjee",
    "screen_name" : "Dibyo13",
    "protected" : false,
    "id_str" : "21480436",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2692919961\/0a7d701ca39a1c35ee6102255665dafd_normal.jpeg",
    "id" : 21480436,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Khushboo Alam",
      "screen_name" : "newfaceoflove",
      "indices" : [ 0, 14 ],
      "id_str" : "141116065",
      "id" : 141116065
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "13554925315",
  "in_reply_to_user_id" : 141116065,
  "text" : "@newfaceoflove Welcome to the Twitterverse!!!",
  "id" : 13554925315,
  "created_at" : "2010-05-07 00:00:00 +0000",
  "in_reply_to_screen_name" : "newfaceoflove",
  "in_reply_to_user_id_str" : "141116065",
  "user" : {
    "name" : "Dibyo Mukherjee",
    "screen_name" : "Dibyo13",
    "protected" : false,
    "id_str" : "21480436",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2692919961\/0a7d701ca39a1c35ee6102255665dafd_normal.jpeg",
    "id" : 21480436,
    "verified" : false
  }
} ]