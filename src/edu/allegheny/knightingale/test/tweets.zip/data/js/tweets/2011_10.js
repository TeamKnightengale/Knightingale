Grailbird.data.tweets_2011_10 = 
 [ {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Anupam Kher",
      "screen_name" : "AnupamPkher",
      "indices" : [ 3, 15 ],
      "id_str" : "76294950",
      "id" : 76294950
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "129379986862903296",
  "text" : "RT @AnupamPkher: If you want to know what God thinks of money, just look at the people he gave it to.:)",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/blackberry.com\/twitter\" rel=\"nofollow\"\u003ETwitter for BlackBerry\u00AE\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "129237860602744832",
    "text" : "If you want to know what God thinks of money, just look at the people he gave it to.:)",
    "id" : 129237860602744832,
    "created_at" : "2011-10-26 16:48:01 +0000",
    "user" : {
      "name" : "Anupam Kher",
      "screen_name" : "AnupamPkher",
      "protected" : false,
      "id_str" : "76294950",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000076844939\/ba0d5ba35497346c2fbd64c2c3a17aad_normal.jpeg",
      "id" : 76294950,
      "verified" : true
    }
  },
  "id" : 129379986862903296,
  "created_at" : "2011-10-27 02:12:47 +0000",
  "user" : {
    "name" : "Dibyo Mukherjee",
    "screen_name" : "Dibyo13",
    "protected" : false,
    "id_str" : "21480436",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2692919961\/0a7d701ca39a1c35ee6102255665dafd_normal.jpeg",
    "id" : 21480436,
    "verified" : false
  }
} ]