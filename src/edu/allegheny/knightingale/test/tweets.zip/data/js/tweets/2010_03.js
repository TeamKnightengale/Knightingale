Grailbird.data.tweets_2010_03 = 
 [ {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chetan Bhagat",
      "screen_name" : "chetan_bhagat",
      "indices" : [ 3, 17 ],
      "id_str" : "44588485",
      "id" : 44588485
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "10265344420",
  "text" : "RT @chetan_bhagat: Sonia G doesn't explain or retort - just does her thing. Right or wrong, gets what she believes in. Huge inspiration.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "10253286700",
    "text" : "Sonia G doesn't explain or retort - just does her thing. Right or wrong, gets what she believes in. Huge inspiration.",
    "id" : 10253286700,
    "created_at" : "2010-03-10 03:19:43 +0000",
    "user" : {
      "name" : "Chetan Bhagat",
      "screen_name" : "chetan_bhagat",
      "protected" : false,
      "id_str" : "44588485",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3291106775\/366fcdbc011a8383610e6973d22cc884_normal.jpeg",
      "id" : 44588485,
      "verified" : true
    }
  },
  "id" : 10265344420,
  "created_at" : "2010-03-10 00:00:00 +0000",
  "user" : {
    "name" : "Dibyo Mukherjee",
    "screen_name" : "Dibyo13",
    "protected" : false,
    "id_str" : "21480436",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2692919961\/0a7d701ca39a1c35ee6102255665dafd_normal.jpeg",
    "id" : 21480436,
    "verified" : false
  }
} ]