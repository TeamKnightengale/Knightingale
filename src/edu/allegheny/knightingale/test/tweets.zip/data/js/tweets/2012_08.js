Grailbird.data.tweets_2012_08 = 
 [ {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "sergey bratus",
      "screen_name" : "sergeybratus",
      "indices" : [ 3, 16 ],
      "id_str" : "354406010",
      "id" : 354406010
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "RandomRevelations",
      "indices" : [ 64, 82 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "237040281722179585",
  "text" : "RT @sergeybratus: Fortune cookies are an early form of Twitter. #RandomRevelations",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "RandomRevelations",
        "indices" : [ 46, 64 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "236997512777584640",
    "text" : "Fortune cookies are an early form of Twitter. #RandomRevelations",
    "id" : 236997512777584640,
    "created_at" : "2012-08-19 01:26:24 +0000",
    "user" : {
      "name" : "sergey bratus",
      "screen_name" : "sergeybratus",
      "protected" : false,
      "id_str" : "354406010",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1512555343\/imgres_normal.jpeg",
      "id" : 354406010,
      "verified" : false
    }
  },
  "id" : 237040281722179585,
  "created_at" : "2012-08-19 04:16:21 +0000",
  "user" : {
    "name" : "Dibyo Mukherjee",
    "screen_name" : "Dibyo13",
    "protected" : false,
    "id_str" : "21480436",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2692919961\/0a7d701ca39a1c35ee6102255665dafd_normal.jpeg",
    "id" : 21480436,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bibek Debroy",
      "screen_name" : "bibekdebroy",
      "indices" : [ 3, 15 ],
      "id_str" : "47543773",
      "id" : 47543773
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "236502617117827072",
  "text" : "RT @bibekdebroy: Good idea to get out of fossil fuels. Only provides fuel to fossils.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/blackberry.com\/twitter\" rel=\"nofollow\"\u003ETwitter for BlackBerry\u00AE\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "236445632884256768",
    "text" : "Good idea to get out of fossil fuels. Only provides fuel to fossils.",
    "id" : 236445632884256768,
    "created_at" : "2012-08-17 12:53:26 +0000",
    "user" : {
      "name" : "Bibek Debroy",
      "screen_name" : "bibekdebroy",
      "protected" : false,
      "id_str" : "47543773",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3031576381\/381d2b95eb3b4e1412dad6bfb1239fbf_normal.jpeg",
      "id" : 47543773,
      "verified" : false
    }
  },
  "id" : 236502617117827072,
  "created_at" : "2012-08-17 16:39:52 +0000",
  "user" : {
    "name" : "Dibyo Mukherjee",
    "screen_name" : "Dibyo13",
    "protected" : false,
    "id_str" : "21480436",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2692919961\/0a7d701ca39a1c35ee6102255665dafd_normal.jpeg",
    "id" : 21480436,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Roma Panganiban",
      "screen_name" : "romapancake",
      "indices" : [ 0, 12 ],
      "id_str" : "62713836",
      "id" : 62713836
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "234106377189093378",
  "geo" : { },
  "id_str" : "234111215817863168",
  "in_reply_to_user_id" : 62713836,
  "text" : "@romapancake I tried too...all in vain",
  "id" : 234111215817863168,
  "in_reply_to_status_id" : 234106377189093378,
  "created_at" : "2012-08-11 02:17:18 +0000",
  "in_reply_to_screen_name" : "romapancake",
  "in_reply_to_user_id_str" : "62713836",
  "user" : {
    "name" : "Dibyo Mukherjee",
    "screen_name" : "Dibyo13",
    "protected" : false,
    "id_str" : "21480436",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2692919961\/0a7d701ca39a1c35ee6102255665dafd_normal.jpeg",
    "id" : 21480436,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Roma Panganiban",
      "screen_name" : "romapancake",
      "indices" : [ 0, 12 ],
      "id_str" : "62713836",
      "id" : 62713836
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "234025931453378560",
  "geo" : { },
  "id_str" : "234033924949544960",
  "in_reply_to_user_id" : 62713836,
  "text" : "@romapancake This is what I did all day!",
  "id" : 234033924949544960,
  "in_reply_to_status_id" : 234025931453378560,
  "created_at" : "2012-08-10 21:10:10 +0000",
  "in_reply_to_screen_name" : "romapancake",
  "in_reply_to_user_id_str" : "62713836",
  "user" : {
    "name" : "Dibyo Mukherjee",
    "screen_name" : "Dibyo13",
    "protected" : false,
    "id_str" : "21480436",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2692919961\/0a7d701ca39a1c35ee6102255665dafd_normal.jpeg",
    "id" : 21480436,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rohan Joshi",
      "screen_name" : "mojorojo",
      "indices" : [ 3, 12 ],
      "id_str" : "18872373",
      "id" : 18872373
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "232262535125008385",
  "text" : "RT @mojorojo: Hey America, new rule. Impulse control or gun control. Choose. If you don't have one, you just get the other. K?",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "232177074805288960",
    "text" : "Hey America, new rule. Impulse control or gun control. Choose. If you don't have one, you just get the other. K?",
    "id" : 232177074805288960,
    "created_at" : "2012-08-05 18:11:42 +0000",
    "user" : {
      "name" : "Rohan Joshi",
      "screen_name" : "mojorojo",
      "protected" : false,
      "id_str" : "18872373",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000739916075\/b5c93d1086ca4cce449ba1a25725e3fb_normal.jpeg",
      "id" : 18872373,
      "verified" : false
    }
  },
  "id" : 232262535125008385,
  "created_at" : "2012-08-05 23:51:18 +0000",
  "user" : {
    "name" : "Dibyo Mukherjee",
    "screen_name" : "Dibyo13",
    "protected" : false,
    "id_str" : "21480436",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2692919961\/0a7d701ca39a1c35ee6102255665dafd_normal.jpeg",
    "id" : 21480436,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gregory Kapfhammer",
      "screen_name" : "GregKapfhammer",
      "indices" : [ 3, 18 ],
      "id_str" : "361673478",
      "id" : 361673478
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Ubuntu",
      "indices" : [ 31, 38 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "232261716694667264",
  "text" : "RT @GregKapfhammer: Do you use #Ubuntu on a laptop? This Web site will remind you about the multitouch gestures supported by this OS: ht ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twmode.sf.net\/\" rel=\"nofollow\"\u003Etwmode\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Ubuntu",
        "indices" : [ 11, 18 ]
      } ],
      "urls" : [ {
        "indices" : [ 114, 134 ],
        "url" : "http:\/\/t.co\/riao4mFt",
        "expanded_url" : "http:\/\/is.gd\/obrNMy",
        "display_url" : "is.gd\/obrNMy"
      } ]
    },
    "geo" : { },
    "id_str" : "232240782457843714",
    "text" : "Do you use #Ubuntu on a laptop? This Web site will remind you about the multitouch gestures supported by this OS: http:\/\/t.co\/riao4mFt",
    "id" : 232240782457843714,
    "created_at" : "2012-08-05 22:24:52 +0000",
    "user" : {
      "name" : "Gregory Kapfhammer",
      "screen_name" : "GregKapfhammer",
      "protected" : false,
      "id_str" : "361673478",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2284981120\/wan4u9fthmpvgug9khsc_normal.jpeg",
      "id" : 361673478,
      "verified" : false
    }
  },
  "id" : 232261716694667264,
  "created_at" : "2012-08-05 23:48:03 +0000",
  "user" : {
    "name" : "Dibyo Mukherjee",
    "screen_name" : "Dibyo13",
    "protected" : false,
    "id_str" : "21480436",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2692919961\/0a7d701ca39a1c35ee6102255665dafd_normal.jpeg",
    "id" : 21480436,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Trey Patrick",
      "screen_name" : "Treyskie",
      "indices" : [ 0, 9 ],
      "id_str" : "332641659",
      "id" : 332641659
    }, {
      "name" : "Jordan Thompson ",
      "screen_name" : "jthompson016",
      "indices" : [ 10, 23 ],
      "id_str" : "545392596",
      "id" : 545392596
    }, {
      "name" : "Evaristo",
      "screen_name" : "NsaRisto",
      "indices" : [ 24, 33 ],
      "id_str" : "424503034",
      "id" : 424503034
    }, {
      "name" : "Daniel Lessoff",
      "screen_name" : "Ehkiru",
      "indices" : [ 34, 41 ],
      "id_str" : "133024138",
      "id" : 133024138
    }, {
      "name" : "Stefan Boesen",
      "screen_name" : "stefanboesen",
      "indices" : [ 42, 55 ],
      "id_str" : "587173876",
      "id" : 587173876
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "231384714110455808",
  "geo" : { },
  "id_str" : "231513424536952832",
  "in_reply_to_user_id" : 332641659,
  "text" : "@Treyskie @jthompson016 @NsaRisto @Ehkiru @stefanboesen I'm gonna try my best to make it.",
  "id" : 231513424536952832,
  "in_reply_to_status_id" : 231384714110455808,
  "created_at" : "2012-08-03 22:14:36 +0000",
  "in_reply_to_screen_name" : "Treyskie",
  "in_reply_to_user_id_str" : "332641659",
  "user" : {
    "name" : "Dibyo Mukherjee",
    "screen_name" : "Dibyo13",
    "protected" : false,
    "id_str" : "21480436",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2692919961\/0a7d701ca39a1c35ee6102255665dafd_normal.jpeg",
    "id" : 21480436,
    "verified" : false
  }
} ]