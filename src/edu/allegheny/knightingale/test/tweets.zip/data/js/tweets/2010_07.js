Grailbird.data.tweets_2010_07 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/www.snaptu.com\" rel=\"nofollow\"\u003ESnaptu\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amitabh Bachchan",
      "screen_name" : "SrBachchan",
      "indices" : [ 3, 14 ],
      "id_str" : "145125358",
      "id" : 145125358
    }, {
      "name" : "Funny Or Fact",
      "screen_name" : "funnyorfact",
      "indices" : [ 19, 31 ],
      "id_str" : "139951730",
      "id" : 139951730
    }, {
      "name" : "Amitabh Bachchan",
      "screen_name" : "SrBachchan",
      "indices" : [ 33, 44 ],
      "id_str" : "145125358",
      "id" : 145125358
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "20069432196",
  "text" : "RT @SrBachchan: RT @funnyorfact: @SrBachchan It costs 38 Trillion$ to create OXYGEN for 6 mnts 4all Human beings on earth. \"TREES DO IT FOR",
  "id" : 20069432196,
  "created_at" : "2010-08-01 00:00:00 +0000",
  "user" : {
    "name" : "Dibyo Mukherjee",
    "screen_name" : "Dibyo13",
    "protected" : false,
    "id_str" : "21480436",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2692919961\/0a7d701ca39a1c35ee6102255665dafd_normal.jpeg",
    "id" : 21480436,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.snaptu.com\" rel=\"nofollow\"\u003ESnaptu\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Konkona Sensharma",
      "screen_name" : "konkonas",
      "indices" : [ 3, 12 ],
      "id_str" : "75854417",
      "id" : 75854417
    }, {
      "name" : "Tejash Doshi",
      "screen_name" : "tejashdoshi",
      "indices" : [ 17, 29 ],
      "id_str" : "44308199",
      "id" : 44308199
    }, {
      "name" : "Konkona Sensharma",
      "screen_name" : "konkonas",
      "indices" : [ 31, 40 ],
      "id_str" : "75854417",
      "id" : 75854417
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "19063650502",
  "text" : "RT @konkonas: RT @tejashdoshi: @konkonas You never know how strong you are until being strong is the only choice you have...",
  "id" : 19063650502,
  "created_at" : "2010-07-21 00:00:00 +0000",
  "user" : {
    "name" : "Dibyo Mukherjee",
    "screen_name" : "Dibyo13",
    "protected" : false,
    "id_str" : "21480436",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2692919961\/0a7d701ca39a1c35ee6102255665dafd_normal.jpeg",
    "id" : 21480436,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vodafone India",
      "screen_name" : "VodafoneIN",
      "indices" : [ 0, 11 ],
      "id_str" : "61180382",
      "id" : 61180382
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "18184258354",
  "geo" : { },
  "id_str" : "18265599456",
  "in_reply_to_user_id" : 61180382,
  "text" : "@VodafoneIN Is it possible to access POP3 e-mail on my phone with Vodafone live?",
  "id" : 18265599456,
  "in_reply_to_status_id" : 18184258354,
  "created_at" : "2010-07-11 00:00:00 +0000",
  "in_reply_to_screen_name" : "VodafoneIN",
  "in_reply_to_user_id_str" : "61180382",
  "user" : {
    "name" : "Dibyo Mukherjee",
    "screen_name" : "Dibyo13",
    "protected" : false,
    "id_str" : "21480436",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2692919961\/0a7d701ca39a1c35ee6102255665dafd_normal.jpeg",
    "id" : 21480436,
    "verified" : false
  }
} ]