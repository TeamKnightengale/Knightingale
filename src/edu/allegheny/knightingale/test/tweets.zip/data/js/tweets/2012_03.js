Grailbird.data.tweets_2012_03 = 
 [ {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chetan Bhagat",
      "screen_name" : "chetan_bhagat",
      "indices" : [ 3, 17 ],
      "id_str" : "44588485",
      "id" : 44588485
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "180649285145202688",
  "text" : "RT @chetan_bhagat: Now we know why India helped make Bangladesh.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/ubersocial.com\" rel=\"nofollow\"\u003EUberSocial for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "180627057460527106",
    "text" : "Now we know why India helped make Bangladesh.",
    "id" : 180627057460527106,
    "created_at" : "2012-03-16 12:10:21 +0000",
    "user" : {
      "name" : "Chetan Bhagat",
      "screen_name" : "chetan_bhagat",
      "protected" : false,
      "id_str" : "44588485",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3291106775\/366fcdbc011a8383610e6973d22cc884_normal.jpeg",
      "id" : 44588485,
      "verified" : true
    }
  },
  "id" : 180649285145202688,
  "created_at" : "2012-03-16 13:38:40 +0000",
  "user" : {
    "name" : "Dibyo Mukherjee",
    "screen_name" : "Dibyo13",
    "protected" : false,
    "id_str" : "21480436",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2692919961\/0a7d701ca39a1c35ee6102255665dafd_normal.jpeg",
    "id" : 21480436,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bollywood Gandu",
      "screen_name" : "BollywoodGandu",
      "indices" : [ 3, 18 ],
      "id_str" : "70652594",
      "id" : 70652594
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ABunchOfMorons",
      "indices" : [ 99, 114 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "179709182927306753",
  "text" : "RT @BollywoodGandu: Rameez Raja making fun of Ajit Agarkar is like Anu Malik making fun of Pritam. #ABunchOfMorons",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/seesmic.com\/\" rel=\"nofollow\"\u003ESeesmic\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ABunchOfMorons",
        "indices" : [ 79, 94 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "179532708408602624",
    "text" : "Rameez Raja making fun of Ajit Agarkar is like Anu Malik making fun of Pritam. #ABunchOfMorons",
    "id" : 179532708408602624,
    "created_at" : "2012-03-13 11:41:47 +0000",
    "user" : {
      "name" : "Bollywood Gandu",
      "screen_name" : "BollywoodGandu",
      "protected" : false,
      "id_str" : "70652594",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000637658990\/41207047c8e095b234b4702f831c7e9c_normal.jpeg",
      "id" : 70652594,
      "verified" : false
    }
  },
  "id" : 179709182927306753,
  "created_at" : "2012-03-13 23:23:02 +0000",
  "user" : {
    "name" : "Dibyo Mukherjee",
    "screen_name" : "Dibyo13",
    "protected" : false,
    "id_str" : "21480436",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2692919961\/0a7d701ca39a1c35ee6102255665dafd_normal.jpeg",
    "id" : 21480436,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gator Green AC",
      "screen_name" : "alleghenygreen",
      "indices" : [ 3, 18 ],
      "id_str" : "148434562",
      "id" : 148434562
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 138 ],
      "url" : "http:\/\/t.co\/n22KUV5s",
      "expanded_url" : "http:\/\/fb.me\/1s5mKZoLx",
      "display_url" : "fb.me\/1s5mKZoLx"
    } ]
  },
  "geo" : { },
  "id_str" : "179708544885592064",
  "text" : "RT @alleghenygreen: Allegheny is a finalist for Second Nature's 2012 Climate Leadership Award. Check out our video... http:\/\/t.co\/n22KUV5s",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.facebook.com\/twitter\" rel=\"nofollow\"\u003EFacebook\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 98, 118 ],
        "url" : "http:\/\/t.co\/n22KUV5s",
        "expanded_url" : "http:\/\/fb.me\/1s5mKZoLx",
        "display_url" : "fb.me\/1s5mKZoLx"
      } ]
    },
    "geo" : { },
    "id_str" : "179572761176453121",
    "text" : "Allegheny is a finalist for Second Nature's 2012 Climate Leadership Award. Check out our video... http:\/\/t.co\/n22KUV5s",
    "id" : 179572761176453121,
    "created_at" : "2012-03-13 14:20:57 +0000",
    "user" : {
      "name" : "Gator Green AC",
      "screen_name" : "alleghenygreen",
      "protected" : false,
      "id_str" : "148434562",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2786060862\/10459d9fe062bde5c4dd5bc79ac44999_normal.png",
      "id" : 148434562,
      "verified" : false
    }
  },
  "id" : 179708544885592064,
  "created_at" : "2012-03-13 23:20:30 +0000",
  "user" : {
    "name" : "Dibyo Mukherjee",
    "screen_name" : "Dibyo13",
    "protected" : false,
    "id_str" : "21480436",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2692919961\/0a7d701ca39a1c35ee6102255665dafd_normal.jpeg",
    "id" : 21480436,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Derek O'Brien",
      "screen_name" : "quizderek",
      "indices" : [ 3, 13 ],
      "id_str" : "120965579",
      "id" : 120965579
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "dravid",
      "indices" : [ 15, 22 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "178187972724797440",
  "text" : "RT @quizderek: #dravid Some champions choose the moment and the hour they want to walk into the sunset. Lesser mortals just fade away",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "dravid",
        "indices" : [ 0, 7 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "178187769858887680",
    "text" : "#dravid Some champions choose the moment and the hour they want to walk into the sunset. Lesser mortals just fade away",
    "id" : 178187769858887680,
    "created_at" : "2012-03-09 18:37:29 +0000",
    "user" : {
      "name" : "Derek O'Brien",
      "screen_name" : "quizderek",
      "protected" : false,
      "id_str" : "120965579",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1584956105\/DOB_PassportPic_normal.jpg",
      "id" : 120965579,
      "verified" : true
    }
  },
  "id" : 178187972724797440,
  "created_at" : "2012-03-09 18:38:17 +0000",
  "user" : {
    "name" : "Dibyo Mukherjee",
    "screen_name" : "Dibyo13",
    "protected" : false,
    "id_str" : "21480436",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2692919961\/0a7d701ca39a1c35ee6102255665dafd_normal.jpeg",
    "id" : 21480436,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Farhan Akhtar",
      "screen_name" : "FarOutAkhtar",
      "indices" : [ 3, 16 ],
      "id_str" : "97865628",
      "id" : 97865628
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "178187398591688704",
  "text" : "RT @FarOutAkhtar: To Rahul Dravid. Thank you for not just being a great cricketer but also by far, the most admirable ambassador of the  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "178185313691238400",
    "text" : "To Rahul Dravid. Thank you for not just being a great cricketer but also by far, the most admirable ambassador of the game. All the best.",
    "id" : 178185313691238400,
    "created_at" : "2012-03-09 18:27:43 +0000",
    "user" : {
      "name" : "Farhan Akhtar",
      "screen_name" : "FarOutAkhtar",
      "protected" : false,
      "id_str" : "97865628",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3358855365\/7ff1d34c16708463327bde8964388b11_normal.jpeg",
      "id" : 97865628,
      "verified" : true
    }
  },
  "id" : 178187398591688704,
  "created_at" : "2012-03-09 18:36:01 +0000",
  "user" : {
    "name" : "Dibyo Mukherjee",
    "screen_name" : "Dibyo13",
    "protected" : false,
    "id_str" : "21480436",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2692919961\/0a7d701ca39a1c35ee6102255665dafd_normal.jpeg",
    "id" : 21480436,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Roma Panganiban",
      "screen_name" : "romapancake",
      "indices" : [ 17, 29 ],
      "id_str" : "62713836",
      "id" : 62713836
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "178187350973759488",
  "text" : "Tweeting because @romapancake told me to!",
  "id" : 178187350973759488,
  "created_at" : "2012-03-09 18:35:49 +0000",
  "user" : {
    "name" : "Dibyo Mukherjee",
    "screen_name" : "Dibyo13",
    "protected" : false,
    "id_str" : "21480436",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2692919961\/0a7d701ca39a1c35ee6102255665dafd_normal.jpeg",
    "id" : 21480436,
    "verified" : false
  }
} ]