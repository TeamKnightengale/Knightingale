Grailbird.data.tweets_2011_04 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/tweetbutton\" rel=\"nofollow\"\u003ETweet Button\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Avaaz",
      "screen_name" : "Avaaz",
      "indices" : [ 64, 70 ],
      "id_str" : "2553151",
      "id" : 2553151
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "annahazare",
      "indices" : [ 11, 22 ]
    }, {
      "text" : "corruption",
      "indices" : [ 33, 44 ]
    }, {
      "text" : "Lokpal",
      "indices" : [ 92, 99 ]
    } ],
    "urls" : [ {
      "indices" : [ 106, 125 ],
      "url" : "http:\/\/t.co\/eI1NBKt",
      "expanded_url" : "http:\/\/www.avaaz.org\/en\/stand_with_anna_hazare_fb\/?twi",
      "display_url" : "avaaz.org\/en\/stand_with_\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "56212567823106048",
  "text" : "Stand with #annahazare to tackle #corruption in India. Sign the @Avaaz petition for the Jan #Lokpal Bill! http:\/\/t.co\/eI1NBKt",
  "id" : 56212567823106048,
  "created_at" : "2011-04-08 04:31:35 +0000",
  "user" : {
    "name" : "Dibyo Mukherjee",
    "screen_name" : "Dibyo13",
    "protected" : false,
    "id_str" : "21480436",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2692919961\/0a7d701ca39a1c35ee6102255665dafd_normal.jpeg",
    "id" : 21480436,
    "verified" : false
  }
} ]