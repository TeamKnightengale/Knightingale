Grailbird.data.tweets_2012_09 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/tweetbutton\" rel=\"nofollow\"\u003ETweet Button\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Upworthy",
      "screen_name" : "Upworthy",
      "indices" : [ 69, 78 ],
      "id_str" : "524396430",
      "id" : 524396430
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 80, 100 ],
      "url" : "http:\/\/t.co\/YeVsYBGN",
      "expanded_url" : "http:\/\/www.upworthy.com\/congrrrratulationsss-piiirrracy-is-legal-now-arrrrrrr?g=2&c=utw1",
      "display_url" : "upworthy.com\/congrrrratulat\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "248924081553018880",
  "text" : "Congrrrraaaatulationssss. Piiirrracy is legal now?!?! Arrrrrrr! (via @Upworthy) http:\/\/t.co\/YeVsYBGN",
  "id" : 248924081553018880,
  "created_at" : "2012-09-20 23:18:20 +0000",
  "user" : {
    "name" : "Dibyo Mukherjee",
    "screen_name" : "Dibyo13",
    "protected" : false,
    "id_str" : "21480436",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2692919961\/0a7d701ca39a1c35ee6102255665dafd_normal.jpeg",
    "id" : 21480436,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/Dibyo13\/status\/247525256951132160\/photo\/1",
      "indices" : [ 0, 20 ],
      "url" : "http:\/\/t.co\/Rume8kVp",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/A29i6OWCcAISawq.jpg",
      "id_str" : "247525256951132162",
      "id" : 247525256951132162,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A29i6OWCcAISawq.jpg",
      "sizes" : [ {
        "h" : 112,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 640,
        "resize" : "fit",
        "w" : 3440
      }, {
        "h" : 63,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/Rume8kVp"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "247525256951132160",
  "text" : "http:\/\/t.co\/Rume8kVp",
  "id" : 247525256951132160,
  "created_at" : "2012-09-17 02:39:55 +0000",
  "user" : {
    "name" : "Dibyo Mukherjee",
    "screen_name" : "Dibyo13",
    "protected" : false,
    "id_str" : "21480436",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2692919961\/0a7d701ca39a1c35ee6102255665dafd_normal.jpeg",
    "id" : 21480436,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/tweetbutton\" rel=\"nofollow\"\u003ETweet Button\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 47, 55 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 22, 42 ],
      "url" : "http:\/\/t.co\/GT9KgZQu",
      "expanded_url" : "http:\/\/youtu.be\/rdIWKytq_q4",
      "display_url" : "youtu.be\/rdIWKytq_q4"
    } ]
  },
  "geo" : { },
  "id_str" : "247028700338606080",
  "text" : "First Look: iPhone 5: http:\/\/t.co\/GT9KgZQu via @youtube",
  "id" : 247028700338606080,
  "created_at" : "2012-09-15 17:46:46 +0000",
  "user" : {
    "name" : "Dibyo Mukherjee",
    "screen_name" : "Dibyo13",
    "protected" : false,
    "id_str" : "21480436",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2692919961\/0a7d701ca39a1c35ee6102255665dafd_normal.jpeg",
    "id" : 21480436,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Allegheny College",
      "screen_name" : "alleghenycol",
      "indices" : [ 3, 16 ],
      "id_str" : "5865752",
      "id" : 5865752
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "245873672735297537",
  "text" : "RT @alleghenycol: Also in the annual US News rankings, Allegheny is the #1 Up-and-Coming liberal arts college in the country! http:\/\/t.c ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootSuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 108, 128 ],
        "url" : "http:\/\/t.co\/O2M58nNE",
        "expanded_url" : "http:\/\/ow.ly\/dExtt",
        "display_url" : "ow.ly\/dExtt"
      } ]
    },
    "geo" : { },
    "id_str" : "245872859724005376",
    "text" : "Also in the annual US News rankings, Allegheny is the #1 Up-and-Coming liberal arts college in the country! http:\/\/t.co\/O2M58nNE",
    "id" : 245872859724005376,
    "created_at" : "2012-09-12 13:13:52 +0000",
    "user" : {
      "name" : "Allegheny College",
      "screen_name" : "alleghenycol",
      "protected" : false,
      "id_str" : "5865752",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/188863124\/TwitterIcon-AC_normal.png",
      "id" : 5865752,
      "verified" : false
    }
  },
  "id" : 245873672735297537,
  "created_at" : "2012-09-12 13:17:06 +0000",
  "user" : {
    "name" : "Dibyo Mukherjee",
    "screen_name" : "Dibyo13",
    "protected" : false,
    "id_str" : "21480436",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2692919961\/0a7d701ca39a1c35ee6102255665dafd_normal.jpeg",
    "id" : 21480436,
    "verified" : false
  }
} ]