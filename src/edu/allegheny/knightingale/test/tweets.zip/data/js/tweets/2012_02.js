Grailbird.data.tweets_2012_02 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Derek O'Brien",
      "screen_name" : "quizderek",
      "indices" : [ 3, 13 ],
      "id_str" : "120965579",
      "id" : 120965579
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "173942098016468992",
  "text" : "RT @quizderek: Hockey is our first love.Cricket is our rich girlfriend",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "173809480788746240",
    "text" : "Hockey is our first love.Cricket is our rich girlfriend",
    "id" : 173809480788746240,
    "created_at" : "2012-02-26 16:39:44 +0000",
    "user" : {
      "name" : "Derek O'Brien",
      "screen_name" : "quizderek",
      "protected" : false,
      "id_str" : "120965579",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1584956105\/DOB_PassportPic_normal.jpg",
      "id" : 120965579,
      "verified" : true
    }
  },
  "id" : 173942098016468992,
  "created_at" : "2012-02-27 01:26:42 +0000",
  "user" : {
    "name" : "Dibyo Mukherjee",
    "screen_name" : "Dibyo13",
    "protected" : false,
    "id_str" : "21480436",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2692919961\/0a7d701ca39a1c35ee6102255665dafd_normal.jpeg",
    "id" : 21480436,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/tweetbutton\" rel=\"nofollow\"\u003ETweet Button\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "wavii boii1212",
      "screen_name" : "wavii",
      "indices" : [ 18, 24 ],
      "id_str" : "1468577538",
      "id" : 1468577538
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 102, 122 ],
      "url" : "https:\/\/t.co\/CxPz2ps",
      "expanded_url" : "https:\/\/wavii.com\/i\/yTpfD",
      "display_url" : "wavii.com\/i\/yTpfD"
    } ]
  },
  "geo" : { },
  "id_str" : "169117570442596352",
  "text" : "I just discovered @wavii - auto-magical news feeds for any topic (seriously!). Join for early access, https:\/\/t.co\/CxPz2ps",
  "id" : 169117570442596352,
  "created_at" : "2012-02-13 17:55:45 +0000",
  "user" : {
    "name" : "Dibyo Mukherjee",
    "screen_name" : "Dibyo13",
    "protected" : false,
    "id_str" : "21480436",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2692919961\/0a7d701ca39a1c35ee6102255665dafd_normal.jpeg",
    "id" : 21480436,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matt Jadud",
      "screen_name" : "jadudm",
      "indices" : [ 3, 10 ],
      "id_str" : "28472174",
      "id" : 28472174
    }, {
      "name" : "Pocket Factory",
      "screen_name" : "PocketFactory22",
      "indices" : [ 65, 81 ],
      "id_str" : "420849386",
      "id" : 420849386
    }, {
      "name" : "Bilal Ghalib",
      "screen_name" : "bilalghalib",
      "indices" : [ 103, 115 ],
      "id_str" : "16154713",
      "id" : 16154713
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 82, 102 ],
      "url" : "http:\/\/t.co\/cNfoFP5I",
      "expanded_url" : "http:\/\/sites.allegheny.edu\/news\/2012\/02\/07\/pocket-factory-22-founders-to-talk-about-innovative-sustainable-modes-of-manufacturing\/",
      "display_url" : "sites.allegheny.edu\/news\/2012\/02\/0\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "167707553684393984",
  "text" : "RT @jadudm: Meadville hosts road-tripping entrepreneurial makers @pocketfactory22 http:\/\/t.co\/cNfoFP5I @bilalghalib",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Pocket Factory",
        "screen_name" : "PocketFactory22",
        "indices" : [ 53, 69 ],
        "id_str" : "420849386",
        "id" : 420849386
      }, {
        "name" : "Bilal Ghalib",
        "screen_name" : "bilalghalib",
        "indices" : [ 91, 103 ],
        "id_str" : "16154713",
        "id" : 16154713
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 70, 90 ],
        "url" : "http:\/\/t.co\/cNfoFP5I",
        "expanded_url" : "http:\/\/sites.allegheny.edu\/news\/2012\/02\/07\/pocket-factory-22-founders-to-talk-about-innovative-sustainable-modes-of-manufacturing\/",
        "display_url" : "sites.allegheny.edu\/news\/2012\/02\/0\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "167002462849474561",
    "text" : "Meadville hosts road-tripping entrepreneurial makers @pocketfactory22 http:\/\/t.co\/cNfoFP5I @bilalghalib",
    "id" : 167002462849474561,
    "created_at" : "2012-02-07 21:51:04 +0000",
    "user" : {
      "name" : "Matt Jadud",
      "screen_name" : "jadudm",
      "protected" : false,
      "id_str" : "28472174",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/126610630\/domokun_normal.jpg",
      "id" : 28472174,
      "verified" : false
    }
  },
  "id" : 167707553684393984,
  "created_at" : "2012-02-09 20:32:51 +0000",
  "user" : {
    "name" : "Dibyo Mukherjee",
    "screen_name" : "Dibyo13",
    "protected" : false,
    "id_str" : "21480436",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2692919961\/0a7d701ca39a1c35ee6102255665dafd_normal.jpeg",
    "id" : 21480436,
    "verified" : false
  }
} ]