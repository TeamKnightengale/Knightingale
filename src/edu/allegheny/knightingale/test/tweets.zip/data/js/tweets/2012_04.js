Grailbird.data.tweets_2012_04 = 
 [ {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Allegheny ",
      "screen_name" : "GhenyProblems",
      "indices" : [ 3, 17 ],
      "id_str" : "371994865",
      "id" : 371994865
    }, {
      "name" : "Daniel Bauer",
      "screen_name" : "danieljflowers",
      "indices" : [ 68, 83 ],
      "id_str" : "183294961",
      "id" : 183294961
    }, {
      "name" : "Charlie Magovern",
      "screen_name" : "cmagovern",
      "indices" : [ 88, 98 ],
      "id_str" : "182453744",
      "id" : 182453744
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "acgunman",
      "indices" : [ 120, 129 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "192830507002769410",
  "text" : "RT @GhenyProblems: Serious talk for a moment: everyone should thank @danieljflowers and @cmagovern for their updates on #acgunman since  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Daniel Bauer",
        "screen_name" : "danieljflowers",
        "indices" : [ 49, 64 ],
        "id_str" : "183294961",
        "id" : 183294961
      }, {
        "name" : "Charlie Magovern",
        "screen_name" : "cmagovern",
        "indices" : [ 69, 79 ],
        "id_str" : "182453744",
        "id" : 182453744
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "acgunman",
        "indices" : [ 101, 110 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "192826589724160001",
    "text" : "Serious talk for a moment: everyone should thank @danieljflowers and @cmagovern for their updates on #acgunman since we have no info from AC",
    "id" : 192826589724160001,
    "created_at" : "2012-04-19 04:06:56 +0000",
    "user" : {
      "name" : "Allegheny ",
      "screen_name" : "GhenyProblems",
      "protected" : false,
      "id_str" : "371994865",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1539012236\/img-placeholder_normal.jpg",
      "id" : 371994865,
      "verified" : false
    }
  },
  "id" : 192830507002769410,
  "created_at" : "2012-04-19 04:22:30 +0000",
  "user" : {
    "name" : "Dibyo Mukherjee",
    "screen_name" : "Dibyo13",
    "protected" : false,
    "id_str" : "21480436",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2692919961\/0a7d701ca39a1c35ee6102255665dafd_normal.jpeg",
    "id" : 21480436,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "acgunman",
      "indices" : [ 102, 111 ]
    }, {
      "text" : "toosoon",
      "indices" : [ 112, 120 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "192819559621857281",
  "text" : "RT @SydtheGingKid: I'm going to say it again. Hopefully he's not as good at hide n seek as bin laden. #acgunman #toosoon",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "acgunman",
        "indices" : [ 83, 92 ]
      }, {
        "text" : "toosoon",
        "indices" : [ 93, 101 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "192818893281169408",
    "text" : "I'm going to say it again. Hopefully he's not as good at hide n seek as bin laden. #acgunman #toosoon",
    "id" : 192818893281169408,
    "created_at" : "2012-04-19 03:36:21 +0000",
    "user" : {
      "name" : "Sydney Cordell",
      "screen_name" : "Sydneycay",
      "protected" : false,
      "id_str" : "22877069",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1317811286\/1304Cyz0_normal",
      "id" : 22877069,
      "verified" : false
    }
  },
  "id" : 192819559621857281,
  "created_at" : "2012-04-19 03:39:00 +0000",
  "user" : {
    "name" : "Dibyo Mukherjee",
    "screen_name" : "Dibyo13",
    "protected" : false,
    "id_str" : "21480436",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2692919961\/0a7d701ca39a1c35ee6102255665dafd_normal.jpeg",
    "id" : 21480436,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amanda MacDonald",
      "screen_name" : "macmanda2890",
      "indices" : [ 0, 13 ],
      "id_str" : "331324923",
      "id" : 331324923
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "acgunman",
      "indices" : [ 31, 40 ]
    }, {
      "text" : "KeithGreenFest",
      "indices" : [ 41, 56 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "192818661168398338",
  "geo" : { },
  "id_str" : "192819139201605632",
  "in_reply_to_user_id" : 331324923,
  "text" : "@macmanda2890 MUST BE ALL TAN. #acgunman #KeithGreenFest",
  "id" : 192819139201605632,
  "in_reply_to_status_id" : 192818661168398338,
  "created_at" : "2012-04-19 03:37:19 +0000",
  "in_reply_to_screen_name" : "macmanda2890",
  "in_reply_to_user_id_str" : "331324923",
  "user" : {
    "name" : "Dibyo Mukherjee",
    "screen_name" : "Dibyo13",
    "protected" : false,
    "id_str" : "21480436",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2692919961\/0a7d701ca39a1c35ee6102255665dafd_normal.jpeg",
    "id" : 21480436,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alex Perlman",
      "screen_name" : "PerlmanAlex",
      "indices" : [ 3, 15 ],
      "id_str" : "373154825",
      "id" : 373154825
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "tanontanman",
      "indices" : [ 98, 110 ]
    }, {
      "text" : "acgunman",
      "indices" : [ 111, 120 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "192803171654041600",
  "text" : "RT @PerlmanAlex: Allegheny college republicans blame Barack Obama for not catching AC gunman.....\n#tanontanman #acgunman",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "tanontanman",
        "indices" : [ 81, 93 ]
      }, {
        "text" : "acgunman",
        "indices" : [ 94, 103 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "192802953906761729",
    "text" : "Allegheny college republicans blame Barack Obama for not catching AC gunman.....\n#tanontanman #acgunman",
    "id" : 192802953906761729,
    "created_at" : "2012-04-19 02:33:00 +0000",
    "user" : {
      "name" : "Alex Perlman",
      "screen_name" : "PerlmanAlex",
      "protected" : false,
      "id_str" : "373154825",
      "profile_image_url_https" : "https:\/\/abs.twimg.com\/sticky\/default_profile_images\/default_profile_1_normal.png",
      "id" : 373154825,
      "verified" : false
    }
  },
  "id" : 192803171654041600,
  "created_at" : "2012-04-19 02:33:52 +0000",
  "user" : {
    "name" : "Dibyo Mukherjee",
    "screen_name" : "Dibyo13",
    "protected" : false,
    "id_str" : "21480436",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2692919961\/0a7d701ca39a1c35ee6102255665dafd_normal.jpeg",
    "id" : 21480436,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Watt",
      "screen_name" : "TheRealJohnWatt",
      "indices" : [ 3, 19 ],
      "id_str" : "518892083",
      "id" : 518892083
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ghenyproblems",
      "indices" : [ 117, 131 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "192770064250978306",
  "text" : "RT @TheRealJohnWatt: It's obvious the gunman is only here for Springfest.  I mean, he did go straight to the Octagon #ghenyproblems",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ghenyproblems",
        "indices" : [ 96, 110 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "192669413479165953",
    "text" : "It's obvious the gunman is only here for Springfest.  I mean, he did go straight to the Octagon #ghenyproblems",
    "id" : 192669413479165953,
    "created_at" : "2012-04-18 17:42:22 +0000",
    "user" : {
      "name" : "John Watt",
      "screen_name" : "TheRealJohnWatt",
      "protected" : false,
      "id_str" : "518892083",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1882314397\/IMAGE_normal.png",
      "id" : 518892083,
      "verified" : false
    }
  },
  "id" : 192770064250978306,
  "created_at" : "2012-04-19 00:22:19 +0000",
  "user" : {
    "name" : "Dibyo Mukherjee",
    "screen_name" : "Dibyo13",
    "protected" : false,
    "id_str" : "21480436",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2692919961\/0a7d701ca39a1c35ee6102255665dafd_normal.jpeg",
    "id" : 21480436,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Allegheny ",
      "screen_name" : "GhenyProblems",
      "indices" : [ 3, 17 ],
      "id_str" : "371994865",
      "id" : 371994865
    }, {
      "name" : "Charlie Magovern",
      "screen_name" : "cmagovern",
      "indices" : [ 60, 70 ],
      "id_str" : "182453744",
      "id" : 182453744
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "acgunman",
      "indices" : [ 87, 96 ]
    }, {
      "text" : "ghenysolutions",
      "indices" : [ 120, 135 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "192770026447708161",
  "text" : "RT @GhenyProblems: That awkward moment when Allegheny's own @cmagovern is tracking the #acgunman better then the police #ghenysolutions",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Charlie Magovern",
        "screen_name" : "cmagovern",
        "indices" : [ 41, 51 ],
        "id_str" : "182453744",
        "id" : 182453744
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "acgunman",
        "indices" : [ 68, 77 ]
      }, {
        "text" : "ghenysolutions",
        "indices" : [ 101, 116 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "192712737292423168",
    "text" : "That awkward moment when Allegheny's own @cmagovern is tracking the #acgunman better then the police #ghenysolutions",
    "id" : 192712737292423168,
    "created_at" : "2012-04-18 20:34:31 +0000",
    "user" : {
      "name" : "Allegheny ",
      "screen_name" : "GhenyProblems",
      "protected" : false,
      "id_str" : "371994865",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1539012236\/img-placeholder_normal.jpg",
      "id" : 371994865,
      "verified" : false
    }
  },
  "id" : 192770026447708161,
  "created_at" : "2012-04-19 00:22:10 +0000",
  "user" : {
    "name" : "Dibyo Mukherjee",
    "screen_name" : "Dibyo13",
    "protected" : false,
    "id_str" : "21480436",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2692919961\/0a7d701ca39a1c35ee6102255665dafd_normal.jpeg",
    "id" : 21480436,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/tweetbutton\" rel=\"nofollow\"\u003ETweet Button\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Elizabeth Frick",
      "screen_name" : "libbyfrick1",
      "indices" : [ 2, 14 ],
      "id_str" : "341548014",
      "id" : 341548014
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ghenyproblems",
      "indices" : [ 92, 106 ]
    } ],
    "urls" : [ {
      "indices" : [ 109, 129 ],
      "url" : "http:\/\/t.co\/PyvP1CFv",
      "expanded_url" : "http:\/\/sfy.co\/os4",
      "display_url" : "sfy.co\/os4"
    } ]
  },
  "geo" : { },
  "id_str" : "192671491215720448",
  "text" : "\u201C\"@libbyfrick1 The only reason allegheny cancels class is for a gunman on north main street #ghenyproblems\"\u201D http:\/\/t.co\/PyvP1CFv",
  "id" : 192671491215720448,
  "created_at" : "2012-04-18 17:50:37 +0000",
  "user" : {
    "name" : "Dibyo Mukherjee",
    "screen_name" : "Dibyo13",
    "protected" : false,
    "id_str" : "21480436",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2692919961\/0a7d701ca39a1c35ee6102255665dafd_normal.jpeg",
    "id" : 21480436,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/tweetbutton\" rel=\"nofollow\"\u003ETweet Button\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "about.me",
      "screen_name" : "aboutdotme",
      "indices" : [ 52, 63 ],
      "id_str" : "115304519",
      "id" : 115304519
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 65, 85 ],
      "url" : "http:\/\/t.co\/8D7h05pB",
      "expanded_url" : "http:\/\/about.me\/dibyom",
      "display_url" : "about.me\/dibyom"
    } ]
  },
  "geo" : { },
  "id_str" : "188304987540037633",
  "text" : "Vote for me to win a paid summer internship through @aboutdotme. http:\/\/t.co\/8D7h05pB",
  "id" : 188304987540037633,
  "created_at" : "2012-04-06 16:39:42 +0000",
  "user" : {
    "name" : "Dibyo Mukherjee",
    "screen_name" : "Dibyo13",
    "protected" : false,
    "id_str" : "21480436",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2692919961\/0a7d701ca39a1c35ee6102255665dafd_normal.jpeg",
    "id" : 21480436,
    "verified" : false
  }
} ]