Grailbird.data.tweets_2011_12 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/tweetbutton\" rel=\"nofollow\"\u003ETweet Button\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 80, 99 ],
      "url" : "http:\/\/t.co\/dBNQXik",
      "expanded_url" : "http:\/\/StayClassy.org",
      "display_url" : "StayClassy.org"
    }, {
      "indices" : [ 100, 119 ],
      "url" : "http:\/\/t.co\/kx3R5FP",
      "expanded_url" : "http:\/\/www.stayclassy.org\/fundraise?fcid=145253",
      "display_url" : "stayclassy.org\/fundraise?fcid\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "151458808223371264",
  "text" : "Check out Rachel  Kosla 's fundraising page for Liberty in North Korea, LiNK on http:\/\/t.co\/dBNQXik http:\/\/t.co\/kx3R5FP",
  "id" : 151458808223371264,
  "created_at" : "2011-12-27 00:26:08 +0000",
  "user" : {
    "name" : "Dibyo Mukherjee",
    "screen_name" : "Dibyo13",
    "protected" : false,
    "id_str" : "21480436",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2692919961\/0a7d701ca39a1c35ee6102255665dafd_normal.jpeg",
    "id" : 21480436,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jesus Christ",
      "screen_name" : "jesus",
      "indices" : [ 3, 9 ],
      "id_str" : "8943",
      "id" : 8943
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "150794487558455296",
  "text" : "RT @jesus: Birthday party is the same theme as last year!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "150770022933999616",
    "text" : "Birthday party is the same theme as last year!",
    "id" : 150770022933999616,
    "created_at" : "2011-12-25 02:49:09 +0000",
    "user" : {
      "name" : "Jesus Christ",
      "screen_name" : "jesus",
      "protected" : false,
      "id_str" : "8943",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000436609149\/959a9ed0624216336e8d253aceb89e2b_normal.jpeg",
      "id" : 8943,
      "verified" : false
    }
  },
  "id" : 150794487558455296,
  "created_at" : "2011-12-25 04:26:22 +0000",
  "user" : {
    "name" : "Dibyo Mukherjee",
    "screen_name" : "Dibyo13",
    "protected" : false,
    "id_str" : "21480436",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2692919961\/0a7d701ca39a1c35ee6102255665dafd_normal.jpeg",
    "id" : 21480436,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Roma Panganiban",
      "screen_name" : "romapancake",
      "indices" : [ 3, 15 ],
      "id_str" : "62713836",
      "id" : 62713836
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "148604896785072128",
  "text" : "RT @romapancake: If you ever use the abbreviation \"leggo\" instead of \"let's go,\" which is ALREADY a contraction, I will think you are an ...",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "148593124455874561",
    "text" : "If you ever use the abbreviation \"leggo\" instead of \"let's go,\" which is ALREADY a contraction, I will think you are an idiot. Guaranteed.",
    "id" : 148593124455874561,
    "created_at" : "2011-12-19 02:38:56 +0000",
    "user" : {
      "name" : "Roma Panganiban",
      "screen_name" : "romapancake",
      "protected" : false,
      "id_str" : "62713836",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2855495765\/19b91ca768206e3a728051adf7fc4e9b_normal.jpeg",
      "id" : 62713836,
      "verified" : false
    }
  },
  "id" : 148604896785072128,
  "created_at" : "2011-12-19 03:25:42 +0000",
  "user" : {
    "name" : "Dibyo Mukherjee",
    "screen_name" : "Dibyo13",
    "protected" : false,
    "id_str" : "21480436",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2692919961\/0a7d701ca39a1c35ee6102255665dafd_normal.jpeg",
    "id" : 21480436,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matt Jadud",
      "screen_name" : "jadudm",
      "indices" : [ 3, 10 ],
      "id_str" : "28472174",
      "id" : 28472174
    }, {
      "name" : "Market House Fridge",
      "screen_name" : "MHFridge",
      "indices" : [ 12, 21 ],
      "id_str" : "432007685",
      "id" : 432007685
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "148478613774274561",
  "text" : "RT @jadudm: @MHFridge Awesome presentation. Good work.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Market House Fridge",
        "screen_name" : "MHFridge",
        "indices" : [ 0, 9 ],
        "id_str" : "432007685",
        "id" : 432007685
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "148477672840904704",
    "in_reply_to_user_id" : 432007685,
    "text" : "@MHFridge Awesome presentation. Good work.",
    "id" : 148477672840904704,
    "created_at" : "2011-12-18 19:00:10 +0000",
    "in_reply_to_screen_name" : "MHFridge",
    "in_reply_to_user_id_str" : "432007685",
    "user" : {
      "name" : "Matt Jadud",
      "screen_name" : "jadudm",
      "protected" : false,
      "id_str" : "28472174",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/126610630\/domokun_normal.jpg",
      "id" : 28472174,
      "verified" : false
    }
  },
  "id" : 148478613774274561,
  "created_at" : "2011-12-18 19:03:54 +0000",
  "user" : {
    "name" : "Dibyo Mukherjee",
    "screen_name" : "Dibyo13",
    "protected" : false,
    "id_str" : "21480436",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2692919961\/0a7d701ca39a1c35ee6102255665dafd_normal.jpeg",
    "id" : 21480436,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/tweetbutton\" rel=\"nofollow\"\u003ETweet Button\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "joinRED",
      "screen_name" : "joinRED",
      "indices" : [ 91, 99 ],
      "id_str" : "13632",
      "id" : 13632
    }, {
      "name" : "ONE",
      "screen_name" : "ONECampaign",
      "indices" : [ 104, 116 ],
      "id_str" : "16348549",
      "id" : 16348549
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "endofAIDS",
      "indices" : [ 29, 39 ]
    } ],
    "urls" : [ {
      "indices" : [ 119, 138 ],
      "url" : "http:\/\/t.co\/drkxHDG",
      "expanded_url" : "http:\/\/klout.com\/perk\/RED\/2015QUILT?passalong=MjczLzg1NTY4Mzk4MDg3NzkzMTkzLzI&passalongSig=d2ff1ba8d6d06d4c1140c42bf5db7e9587dccfedebbaf963139e6466c4371689&n=tw&v=perks_completed",
      "display_url" : "klout.com\/perk\/RED\/2015Q\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "148170070621822976",
  "text" : "Join me in the fight for the #endofAIDS by adding your voice to the (2015)QUILT created by @joinRED and @ONEcampaign.  http:\/\/t.co\/drkxHDG",
  "id" : 148170070621822976,
  "created_at" : "2011-12-17 22:37:52 +0000",
  "user" : {
    "name" : "Dibyo Mukherjee",
    "screen_name" : "Dibyo13",
    "protected" : false,
    "id_str" : "21480436",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2692919961\/0a7d701ca39a1c35ee6102255665dafd_normal.jpeg",
    "id" : 21480436,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/tweetbutton\" rel=\"nofollow\"\u003ETweet Button\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Klout",
      "screen_name" : "klout",
      "indices" : [ 48, 54 ],
      "id_str" : "15134782",
      "id" : 15134782
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 70, 89 ],
      "url" : "http:\/\/t.co\/RdqHErY",
      "expanded_url" : "http:\/\/klout.com\/user\/Dibyo13\/achievements?n=tw&v=achievement_earned_modal",
      "display_url" : "klout.com\/user\/Dibyo13\/a\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "148169408739672064",
  "text" : "I earned the 'Making it Rain +K' achievement on @klout, check it out! http:\/\/t.co\/RdqHErY",
  "id" : 148169408739672064,
  "created_at" : "2011-12-17 22:35:14 +0000",
  "user" : {
    "name" : "Dibyo Mukherjee",
    "screen_name" : "Dibyo13",
    "protected" : false,
    "id_str" : "21480436",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2692919961\/0a7d701ca39a1c35ee6102255665dafd_normal.jpeg",
    "id" : 21480436,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shashi Tharoor",
      "screen_name" : "ShashiTharoor",
      "indices" : [ 3, 17 ],
      "id_str" : "24705126",
      "id" : 24705126
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "145341499620605952",
  "text" : "RT @ShashiTharoor: Heroism amid Kolkata hospital fire: nurses P.K.Vineetha &Remya Rajan saved 8 patients in female ward,died in valiant  ...",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "145335171011448832",
    "text" : "Heroism amid Kolkata hospital fire: nurses P.K.Vineetha &Remya Rajan saved 8 patients in female ward,died in valiant attempt to rescue 9th",
    "id" : 145335171011448832,
    "created_at" : "2011-12-10 02:52:59 +0000",
    "user" : {
      "name" : "Shashi Tharoor",
      "screen_name" : "ShashiTharoor",
      "protected" : false,
      "id_str" : "24705126",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3704803551\/74ac7fac7e0833cf354faad131ff6c64_normal.jpeg",
      "id" : 24705126,
      "verified" : true
    }
  },
  "id" : 145341499620605952,
  "created_at" : "2011-12-10 03:18:08 +0000",
  "user" : {
    "name" : "Dibyo Mukherjee",
    "screen_name" : "Dibyo13",
    "protected" : false,
    "id_str" : "21480436",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2692919961\/0a7d701ca39a1c35ee6102255665dafd_normal.jpeg",
    "id" : 21480436,
    "verified" : false
  }
} ]