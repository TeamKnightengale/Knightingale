Grailbird.data.tweets_2013_09 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "FlashStarts",
      "screen_name" : "FlashStarts",
      "indices" : [ 3, 15 ],
      "id_str" : "1467414068",
      "id" : 1467414068
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Cleveland",
      "indices" : [ 17, 27 ]
    }, {
      "text" : "FSDDay",
      "indices" : [ 56, 63 ]
    } ],
    "urls" : [ {
      "indices" : [ 108, 130 ],
      "url" : "http:\/\/t.co\/68rzoFj0MH",
      "expanded_url" : "http:\/\/bit.ly\/14eknwz",
      "display_url" : "bit.ly\/14eknwz"
    } ]
  },
  "geo" : { },
  "id_str" : "381869433050116096",
  "text" : "RT @FlashStarts: #Cleveland is a part of something big! #FSDDay is tomorrow, 9\/23 at 11:30 am EST. Watch at http:\/\/t.co\/68rzoFj0MH http:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/FlashStarts\/status\/381866902366064640\/photo\/1",
        "indices" : [ 114, 136 ],
        "url" : "http:\/\/t.co\/Q9f3yzCn4y",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BUyp7KGCIAAL36q.png",
        "id_str" : "381866902206685184",
        "id" : 381866902206685184,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BUyp7KGCIAAL36q.png",
        "sizes" : [ {
          "h" : 347,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 530,
          "resize" : "fit",
          "w" : 520
        }, {
          "h" : 530,
          "resize" : "fit",
          "w" : 520
        }, {
          "h" : 530,
          "resize" : "fit",
          "w" : 520
        } ],
        "display_url" : "pic.twitter.com\/Q9f3yzCn4y"
      } ],
      "hashtags" : [ {
        "text" : "Cleveland",
        "indices" : [ 0, 10 ]
      }, {
        "text" : "FSDDay",
        "indices" : [ 39, 46 ]
      } ],
      "urls" : [ {
        "indices" : [ 91, 113 ],
        "url" : "http:\/\/t.co\/68rzoFj0MH",
        "expanded_url" : "http:\/\/bit.ly\/14eknwz",
        "display_url" : "bit.ly\/14eknwz"
      } ]
    },
    "geo" : { },
    "id_str" : "381866902366064640",
    "text" : "#Cleveland is a part of something big! #FSDDay is tomorrow, 9\/23 at 11:30 am EST. Watch at http:\/\/t.co\/68rzoFj0MH http:\/\/t.co\/Q9f3yzCn4y",
    "id" : 381866902366064640,
    "created_at" : "2013-09-22 19:45:38 +0000",
    "user" : {
      "name" : "FlashStarts",
      "screen_name" : "FlashStarts",
      "protected" : false,
      "id_str" : "1467414068",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000318914220\/9b0c206d7525c7af2cd9db9b482131e0_normal.png",
      "id" : 1467414068,
      "verified" : false
    }
  },
  "id" : 381869433050116096,
  "created_at" : "2013-09-22 19:55:42 +0000",
  "user" : {
    "name" : "Dibyo Mukherjee",
    "screen_name" : "Dibyo13",
    "protected" : false,
    "id_str" : "21480436",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2692919961\/0a7d701ca39a1c35ee6102255665dafd_normal.jpeg",
    "id" : 21480436,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Medium",
      "screen_name" : "Medium",
      "indices" : [ 3, 10 ],
      "id_str" : "571202103",
      "id" : 571202103
    }, {
      "name" : "Dr Angus Woodman",
      "screen_name" : "angusw",
      "indices" : [ 37, 44 ],
      "id_str" : "1349371",
      "id" : 1349371
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 45, 68 ],
      "url" : "https:\/\/t.co\/bWZ43gsPZ5",
      "expanded_url" : "https:\/\/medium.com\/editors-picks\/3a102d3b025d?utm_source=TwitterAccount&utm_medium=Twitter&utm_campaign=TwitterAccount",
      "display_url" : "medium.com\/editors-picks\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "381042813305389056",
  "text" : "RT @Medium: \u201CiOS7 and War Crimes\u201D by @angusw https:\/\/t.co\/bWZ43gsPZ5",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/sproutsocial.com\" rel=\"nofollow\"\u003ESprout Social\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Dr Angus Woodman",
        "screen_name" : "angusw",
        "indices" : [ 25, 32 ],
        "id_str" : "1349371",
        "id" : 1349371
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 33, 56 ],
        "url" : "https:\/\/t.co\/bWZ43gsPZ5",
        "expanded_url" : "https:\/\/medium.com\/editors-picks\/3a102d3b025d?utm_source=TwitterAccount&utm_medium=Twitter&utm_campaign=TwitterAccount",
        "display_url" : "medium.com\/editors-picks\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "381040297930551296",
    "text" : "\u201CiOS7 and War Crimes\u201D by @angusw https:\/\/t.co\/bWZ43gsPZ5",
    "id" : 381040297930551296,
    "created_at" : "2013-09-20 13:01:01 +0000",
    "user" : {
      "name" : "Medium",
      "screen_name" : "Medium",
      "protected" : false,
      "id_str" : "571202103",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2504297462\/wtbq3hoquj8no6t2ysz4_normal.jpeg",
      "id" : 571202103,
      "verified" : true
    }
  },
  "id" : 381042813305389056,
  "created_at" : "2013-09-20 13:11:00 +0000",
  "user" : {
    "name" : "Dibyo Mukherjee",
    "screen_name" : "Dibyo13",
    "protected" : false,
    "id_str" : "21480436",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2692919961\/0a7d701ca39a1c35ee6102255665dafd_normal.jpeg",
    "id" : 21480436,
    "verified" : false
  }
} ]