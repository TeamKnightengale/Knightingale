Grailbird.data.tweets_2013_03 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/www.cs.allegheny.edu\/sites\/gkapfham\" rel=\"nofollow\"\u003EGregKapfhammerClient\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "314473327412518912",
  "text" : "Trying out Twitter4J!",
  "id" : 314473327412518912,
  "created_at" : "2013-03-20 20:27:38 +0000",
  "user" : {
    "name" : "Dibyo Mukherjee",
    "screen_name" : "Dibyo13",
    "protected" : false,
    "id_str" : "21480436",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2692919961\/0a7d701ca39a1c35ee6102255665dafd_normal.jpeg",
    "id" : 21480436,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/tweetbutton\" rel=\"nofollow\"\u003ETweet Button\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 87, 109 ],
      "url" : "http:\/\/t.co\/evfFhw5Aec",
      "expanded_url" : "http:\/\/kufikia.com\/",
      "display_url" : "kufikia.com"
    } ]
  },
  "geo" : { },
  "id_str" : "313181545915621376",
  "text" : "I just signed up for kufikia. I'm learning a new technology and getting paid to do it. http:\/\/t.co\/evfFhw5Aec",
  "id" : 313181545915621376,
  "created_at" : "2013-03-17 06:54:33 +0000",
  "user" : {
    "name" : "Dibyo Mukherjee",
    "screen_name" : "Dibyo13",
    "protected" : false,
    "id_str" : "21480436",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2692919961\/0a7d701ca39a1c35ee6102255665dafd_normal.jpeg",
    "id" : 21480436,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SUHEL SETH",
      "screen_name" : "suhelseth",
      "indices" : [ 0, 10 ],
      "id_str" : "37168231",
      "id" : 37168231
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 11, 33 ],
      "url" : "http:\/\/t.co\/NXFshXEBYb",
      "expanded_url" : "http:\/\/grist.org\/news\/how-to-respond-to-people-who-say-the-cold-weather-disproves-global-warming\/",
      "display_url" : "grist.org\/news\/how-to-re\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "311186291997941760",
  "geo" : { },
  "id_str" : "311268179819249665",
  "in_reply_to_user_id" : 37168231,
  "text" : "@suhelseth http:\/\/t.co\/NXFshXEBYb",
  "id" : 311268179819249665,
  "in_reply_to_status_id" : 311186291997941760,
  "created_at" : "2013-03-12 00:11:31 +0000",
  "in_reply_to_screen_name" : "suhelseth",
  "in_reply_to_user_id_str" : "37168231",
  "user" : {
    "name" : "Dibyo Mukherjee",
    "screen_name" : "Dibyo13",
    "protected" : false,
    "id_str" : "21480436",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2692919961\/0a7d701ca39a1c35ee6102255665dafd_normal.jpeg",
    "id" : 21480436,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/tweetbutton\" rel=\"nofollow\"\u003ETweet Button\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 112, 134 ],
      "url" : "http:\/\/t.co\/XrIoBHRCR8",
      "expanded_url" : "http:\/\/go.codeschool.com\/lAnI_A#.UTlqHbxdYv8.twitter",
      "display_url" : "go.codeschool.com\/lAnI_A#.UTlqHb\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "309884600056958977",
  "text" : "I just got full access to Code School for 48 hours! Get your Hall Pass now and go on a learning-spree for free: http:\/\/t.co\/XrIoBHRCR8",
  "id" : 309884600056958977,
  "created_at" : "2013-03-08 04:33:40 +0000",
  "user" : {
    "name" : "Dibyo Mukherjee",
    "screen_name" : "Dibyo13",
    "protected" : false,
    "id_str" : "21480436",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2692919961\/0a7d701ca39a1c35ee6102255665dafd_normal.jpeg",
    "id" : 21480436,
    "verified" : false
  }
} ]