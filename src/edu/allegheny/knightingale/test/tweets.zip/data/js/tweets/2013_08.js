Grailbird.data.tweets_2013_08 = 
 [ {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "FlashStarts",
      "screen_name" : "FlashStarts",
      "indices" : [ 3, 15 ],
      "id_str" : "1467414068",
      "id" : 1467414068
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "369548961385693185",
  "text" : "RT @FlashStarts: Official FlashStarts Announcement: Our inaugural Demo Day will be Sept 23, &amp; will include a live Internet broadcast | http\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootSuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 122, 144 ],
        "url" : "http:\/\/t.co\/GHKTrNaWgX",
        "expanded_url" : "http:\/\/ow.ly\/o3PFD",
        "display_url" : "ow.ly\/o3PFD"
      } ]
    },
    "geo" : { },
    "id_str" : "369517988623294464",
    "text" : "Official FlashStarts Announcement: Our inaugural Demo Day will be Sept 23, &amp; will include a live Internet broadcast | http:\/\/t.co\/GHKTrNaWgX",
    "id" : 369517988623294464,
    "created_at" : "2013-08-19 17:55:28 +0000",
    "user" : {
      "name" : "FlashStarts",
      "screen_name" : "FlashStarts",
      "protected" : false,
      "id_str" : "1467414068",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000318914220\/9b0c206d7525c7af2cd9db9b482131e0_normal.png",
      "id" : 1467414068,
      "verified" : false
    }
  },
  "id" : 369548961385693185,
  "created_at" : "2013-08-19 19:58:32 +0000",
  "user" : {
    "name" : "Dibyo Mukherjee",
    "screen_name" : "Dibyo13",
    "protected" : false,
    "id_str" : "21480436",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2692919961\/0a7d701ca39a1c35ee6102255665dafd_normal.jpeg",
    "id" : 21480436,
    "verified" : false
  }
} ]