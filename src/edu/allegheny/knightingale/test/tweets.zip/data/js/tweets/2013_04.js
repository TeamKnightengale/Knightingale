Grailbird.data.tweets_2013_04 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/tweetbutton\" rel=\"nofollow\"\u003ETweet Button\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "fromEvernote",
      "indices" : [ 13, 26 ]
    } ],
    "urls" : [ {
      "indices" : [ 27, 50 ],
      "url" : "https:\/\/t.co\/XDaHpuS92K",
      "expanded_url" : "https:\/\/www.evernote.com\/shard\/s10\/sh\/0580fed9-10ec-4ef6-8349-4b260ef8d257\/a5264623e4234d6958727c0b67fa9512",
      "display_url" : "evernote.com\/shard\/s10\/sh\/0\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "319306905740800000",
  "text" : "Inspire Talk #fromEvernote https:\/\/t.co\/XDaHpuS92K",
  "id" : 319306905740800000,
  "created_at" : "2013-04-03 04:34:33 +0000",
  "user" : {
    "name" : "Dibyo Mukherjee",
    "screen_name" : "Dibyo13",
    "protected" : false,
    "id_str" : "21480436",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2692919961\/0a7d701ca39a1c35ee6102255665dafd_normal.jpeg",
    "id" : 21480436,
    "verified" : false
  }
} ]