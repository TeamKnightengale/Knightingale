Grailbird.data.tweets_2012_10 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Anonymous",
      "screen_name" : "YourAnonNews",
      "indices" : [ 3, 16 ],
      "id_str" : "279390084",
      "id" : 279390084
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Sandy",
      "indices" : [ 22, 28 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "263130043444781057",
  "text" : "RT @YourAnonNews: No, #Sandy is not evidence of God's wrath. It's evidence of our refusal to even discuss climate change &amp; global wa ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Sandy",
        "indices" : [ 4, 10 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "263111097370947584",
    "text" : "No, #Sandy is not evidence of God's wrath. It's evidence of our refusal to even discuss climate change &amp; global warning.",
    "id" : 263111097370947584,
    "created_at" : "2012-10-30 02:52:28 +0000",
    "user" : {
      "name" : "Anonymous",
      "screen_name" : "YourAnonNews",
      "protected" : false,
      "id_str" : "279390084",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1769643466\/258844_104131489680984_104118713015595_32268_721285_o__1__normal.jpeg",
      "id" : 279390084,
      "verified" : false
    }
  },
  "id" : 263130043444781057,
  "created_at" : "2012-10-30 04:07:45 +0000",
  "user" : {
    "name" : "Dibyo Mukherjee",
    "screen_name" : "Dibyo13",
    "protected" : false,
    "id_str" : "21480436",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2692919961\/0a7d701ca39a1c35ee6102255665dafd_normal.jpeg",
    "id" : 21480436,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/tweetbutton\" rel=\"nofollow\"\u003ETweet Button\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 62, 82 ],
      "url" : "http:\/\/t.co\/YN1NJCvn",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=dX_1B0w7Hzc",
      "display_url" : "youtube.com\/watch?v=dX_1B0\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "260593380709498880",
  "text" : "Barack Obama vs Mitt Romney - Epic Rap Battles of History!    http:\/\/t.co\/YN1NJCvn",
  "id" : 260593380709498880,
  "created_at" : "2012-10-23 04:07:58 +0000",
  "user" : {
    "name" : "Dibyo Mukherjee",
    "screen_name" : "Dibyo13",
    "protected" : false,
    "id_str" : "21480436",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2692919961\/0a7d701ca39a1c35ee6102255665dafd_normal.jpeg",
    "id" : 21480436,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rajdeep Sardesai",
      "screen_name" : "sardesairajdeep",
      "indices" : [ 3, 19 ],
      "id_str" : "56304605",
      "id" : 56304605
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "259885759996248065",
  "text" : "RT @sardesairajdeep: And oh yes, Shubho saptami to all!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "259871175214239744",
    "text" : "And oh yes, Shubho saptami to all!",
    "id" : 259871175214239744,
    "created_at" : "2012-10-21 04:18:11 +0000",
    "user" : {
      "name" : "Rajdeep Sardesai",
      "screen_name" : "sardesairajdeep",
      "protected" : false,
      "id_str" : "56304605",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/347293067\/Untitled-1_copy_normal.jpg",
      "id" : 56304605,
      "verified" : true
    }
  },
  "id" : 259885759996248065,
  "created_at" : "2012-10-21 05:16:08 +0000",
  "user" : {
    "name" : "Dibyo Mukherjee",
    "screen_name" : "Dibyo13",
    "protected" : false,
    "id_str" : "21480436",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2692919961\/0a7d701ca39a1c35ee6102255665dafd_normal.jpeg",
    "id" : 21480436,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/tweetbutton\" rel=\"nofollow\"\u003ETweet Button\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Nation",
      "screen_name" : "thenation",
      "indices" : [ 58, 68 ],
      "id_str" : "1947301",
      "id" : 1947301
    }, {
      "name" : "Upworthy",
      "screen_name" : "Upworthy",
      "indices" : [ 74, 83 ],
      "id_str" : "524396430",
      "id" : 524396430
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "stopandfrisk",
      "indices" : [ 33, 46 ]
    } ],
    "urls" : [ {
      "indices" : [ 85, 105 ],
      "url" : "http:\/\/t.co\/CJuiKOiZ",
      "expanded_url" : "http:\/\/www.upworthy.com\/meet-the-17-year-old-who-blew-the-lid-off-racial-profiling-with-his-ipod?g=2",
      "display_url" : "upworthy.com\/meet-the-17-ye\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "258021159570923521",
  "text" : "Secret recordings uncover NYPD's #stopandfrisk in action. @TheNation (via @Upworthy) http:\/\/t.co\/CJuiKOiZ",
  "id" : 258021159570923521,
  "created_at" : "2012-10-16 01:46:52 +0000",
  "user" : {
    "name" : "Dibyo Mukherjee",
    "screen_name" : "Dibyo13",
    "protected" : false,
    "id_str" : "21480436",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2692919961\/0a7d701ca39a1c35ee6102255665dafd_normal.jpeg",
    "id" : 21480436,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shashi Tharoor",
      "screen_name" : "ShashiTharoor",
      "indices" : [ 36, 50 ],
      "id_str" : "24705126",
      "id" : 24705126
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "255129141937057794",
  "text" : "Got my copy of Pax Indica signed by @ShashiTharoor !",
  "id" : 255129141937057794,
  "created_at" : "2012-10-08 02:15:02 +0000",
  "user" : {
    "name" : "Dibyo Mukherjee",
    "screen_name" : "Dibyo13",
    "protected" : false,
    "id_str" : "21480436",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2692919961\/0a7d701ca39a1c35ee6102255665dafd_normal.jpeg",
    "id" : 21480436,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Barack Obama",
      "screen_name" : "BarackObama",
      "indices" : [ 3, 15 ],
      "id_str" : "813286",
      "id" : 813286
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "TeamObama",
      "indices" : [ 33, 43 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "253687336016175107",
  "text" : "RT @BarackObama: RT if you're on #TeamObama tonight.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.barackobama.com\/\" rel=\"nofollow\"\u003EObama for America\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "TeamObama",
        "indices" : [ 16, 26 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "253686037140877312",
    "text" : "RT if you're on #TeamObama tonight.",
    "id" : 253686037140877312,
    "created_at" : "2012-10-04 02:40:39 +0000",
    "user" : {
      "name" : "Barack Obama",
      "screen_name" : "BarackObama",
      "protected" : false,
      "id_str" : "813286",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000607588261\/dad9f009a228a78a14f1f4bed0c54f76_normal.png",
      "id" : 813286,
      "verified" : true
    }
  },
  "id" : 253687336016175107,
  "created_at" : "2012-10-04 02:45:48 +0000",
  "user" : {
    "name" : "Dibyo Mukherjee",
    "screen_name" : "Dibyo13",
    "protected" : false,
    "id_str" : "21480436",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2692919961\/0a7d701ca39a1c35ee6102255665dafd_normal.jpeg",
    "id" : 21480436,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Simple Millions",
      "screen_name" : "truthteam2012",
      "indices" : [ 3, 17 ],
      "id_str" : "2187254713",
      "id" : 2187254713
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "253673321751797761",
  "text" : "RT @truthteam2012: FACT: If Romney pays for his tax plan as he's promised, middle-class families with kids could see their taxes increas ...",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "253664864688566272",
    "text" : "FACT: If Romney pays for his tax plan as he's promised, middle-class families with kids could see their taxes increase by an avg of $2,041.",
    "id" : 253664864688566272,
    "created_at" : "2012-10-04 01:16:31 +0000",
    "user" : {
      "name" : "OFA TruthTeam",
      "screen_name" : "OFATruthTeam",
      "protected" : false,
      "id_str" : "340333435",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000610548832\/a2cd27ea881197e3ba7760ffa487e109_normal.jpeg",
      "id" : 340333435,
      "verified" : false
    }
  },
  "id" : 253673321751797761,
  "created_at" : "2012-10-04 01:50:07 +0000",
  "user" : {
    "name" : "Dibyo Mukherjee",
    "screen_name" : "Dibyo13",
    "protected" : false,
    "id_str" : "21480436",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2692919961\/0a7d701ca39a1c35ee6102255665dafd_normal.jpeg",
    "id" : 21480436,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "253670438704660481",
  "text" : "I like green energy as well. ...Romney did not just say that",
  "id" : 253670438704660481,
  "created_at" : "2012-10-04 01:38:40 +0000",
  "user" : {
    "name" : "Dibyo Mukherjee",
    "screen_name" : "Dibyo13",
    "protected" : false,
    "id_str" : "21480436",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2692919961\/0a7d701ca39a1c35ee6102255665dafd_normal.jpeg",
    "id" : 21480436,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Neil deGrasse Tyson",
      "screen_name" : "neiltyson",
      "indices" : [ 3, 13 ],
      "id_str" : "19725644",
      "id" : 19725644
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "253668455075700738",
  "text" : "RT @neiltyson: Hmm. Obama &amp; Romney spent 22 min on job-creation with hardly a sentence on the seminal role of sci-tech innovation in ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "253667628231557120",
    "text" : "Hmm. Obama &amp; Romney spent 22 min on job-creation with hardly a sentence on the seminal role of sci-tech innovation in 21st century economies",
    "id" : 253667628231557120,
    "created_at" : "2012-10-04 01:27:30 +0000",
    "user" : {
      "name" : "Neil deGrasse Tyson",
      "screen_name" : "neiltyson",
      "protected" : false,
      "id_str" : "19725644",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/74188698\/NeilTysonOriginsA-Crop_normal.jpg",
      "id" : 19725644,
      "verified" : true
    }
  },
  "id" : 253668455075700738,
  "created_at" : "2012-10-04 01:30:47 +0000",
  "user" : {
    "name" : "Dibyo Mukherjee",
    "screen_name" : "Dibyo13",
    "protected" : false,
    "id_str" : "21480436",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2692919961\/0a7d701ca39a1c35ee6102255665dafd_normal.jpeg",
    "id" : 21480436,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Upworthy",
      "screen_name" : "Upworthy",
      "indices" : [ 3, 12 ],
      "id_str" : "524396430",
      "id" : 524396430
    }, {
      "name" : "Mitt Romney",
      "screen_name" : "MittRomney",
      "indices" : [ 18, 29 ],
      "id_str" : "50055701",
      "id" : 50055701
    }, {
      "name" : "Mitt Romney",
      "screen_name" : "MittRomney",
      "indices" : [ 76, 87 ],
      "id_str" : "50055701",
      "id" : 50055701
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "253667081470500864",
  "text" : "RT @Upworthy: Did @MittRomney just say he doesn't support his own tax plan? @MittRomney",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Mitt Romney",
        "screen_name" : "MittRomney",
        "indices" : [ 4, 15 ],
        "id_str" : "50055701",
        "id" : 50055701
      }, {
        "name" : "Mitt Romney",
        "screen_name" : "MittRomney",
        "indices" : [ 62, 73 ],
        "id_str" : "50055701",
        "id" : 50055701
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "253665285075243008",
    "text" : "Did @MittRomney just say he doesn't support his own tax plan? @MittRomney",
    "id" : 253665285075243008,
    "created_at" : "2012-10-04 01:18:11 +0000",
    "user" : {
      "name" : "Upworthy",
      "screen_name" : "Upworthy",
      "protected" : false,
      "id_str" : "524396430",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000615185360\/1994e844c23204e40701a4daf07c4aef_normal.png",
      "id" : 524396430,
      "verified" : true
    }
  },
  "id" : 253667081470500864,
  "created_at" : "2012-10-04 01:25:19 +0000",
  "user" : {
    "name" : "Dibyo Mukherjee",
    "screen_name" : "Dibyo13",
    "protected" : false,
    "id_str" : "21480436",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2692919961\/0a7d701ca39a1c35ee6102255665dafd_normal.jpeg",
    "id" : 21480436,
    "verified" : false
  }
} ]