var user_details =  {
  "screen_name" : "Dibyo13",
  "location" : "Meadville, PA",
  "full_name" : "Dibyo Mukherjee",
  "id" : "21480436",
  "created_at" : "2009-02-21 12:38:39 +0000"
}