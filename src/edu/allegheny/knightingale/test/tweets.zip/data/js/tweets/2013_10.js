Grailbird.data.tweets_2013_10 = 
[ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/tweetbutton\" rel=\"nofollow\"\u003ETweet Button\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kite",
      "screen_name" : "kitecrew",
      "indices" : [ 15, 24 ],
      "id_str" : "1558574262",
      "id" : 1558574262
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 62 ],
      "url" : "https:\/\/t.co\/9BuQkZGzWc",
      "expanded_url" : "https:\/\/www.runkite.com\/signup?referral=57c7d783-c33d-481e-a145-832bca7d7dcf",
      "display_url" : "runkite.com\/signup?referra\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "389949065166721024",
  "text" : "Check out Kite @kitecrew! Signup here: https:\/\/t.co\/9BuQkZGzWc",
  "id" : 389949065166721024,
  "created_at" : "2013-10-15 03:01:16 +0000",
  "user" : {
    "name" : "Dibyo Mukherjee",
    "screen_name" : "Dibyo13",
    "protected" : false,
    "id_str" : "21480436",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2692919961\/0a7d701ca39a1c35ee6102255665dafd_normal.jpeg",
    "id" : 21480436,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "HackMIT",
      "screen_name" : "HackMIT",
      "indices" : [ 3, 11 ],
      "id_str" : "1338324476",
      "id" : 1338324476
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "NapMIT",
      "indices" : [ 13, 20 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "387064422667022336",
  "text" : "RT @HackMIT: #NapMIT",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "NapMIT",
        "indices" : [ 0, 7 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "386995588937838592",
    "text" : "#NapMIT",
    "id" : 386995588937838592,
    "created_at" : "2013-10-06 23:25:13 +0000",
    "user" : {
      "name" : "HackMIT",
      "screen_name" : "HackMIT",
      "protected" : false,
      "id_str" : "1338324476",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000540625672\/3fdc3b24c0e10068bf6b1f6f1627288b_normal.jpeg",
      "id" : 1338324476,
      "verified" : false
    }
  },
  "id" : 387064422667022336,
  "created_at" : "2013-10-07 03:58:44 +0000",
  "user" : {
    "name" : "Dibyo Mukherjee",
    "screen_name" : "Dibyo13",
    "protected" : false,
    "id_str" : "21480436",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2692919961\/0a7d701ca39a1c35ee6102255665dafd_normal.jpeg",
    "id" : 21480436,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "HackMIT",
      "screen_name" : "HackMIT",
      "indices" : [ 0, 8 ],
      "id_str" : "1338324476",
      "id" : 1338324476
    }, {
      "name" : "Square",
      "screen_name" : "Square",
      "indices" : [ 64, 71 ],
      "id_str" : "93017945",
      "id" : 93017945
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.3558492, -71.05941 ]
  },
  "id_str" : "386952836409356288",
  "in_reply_to_user_id" : 1338324476,
  "text" : "@HackMIT was 30 hours of awesome!!! And thank you for the prize @Square!",
  "id" : 386952836409356288,
  "created_at" : "2013-10-06 20:35:20 +0000",
  "in_reply_to_screen_name" : "HackMIT",
  "in_reply_to_user_id_str" : "1338324476",
  "user" : {
    "name" : "Dibyo Mukherjee",
    "screen_name" : "Dibyo13",
    "protected" : false,
    "id_str" : "21480436",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2692919961\/0a7d701ca39a1c35ee6102255665dafd_normal.jpeg",
    "id" : 21480436,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Drew Josephs",
      "screen_name" : "officeresquire",
      "indices" : [ 3, 18 ],
      "id_str" : "233648614",
      "id" : 233648614
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "OneCookieRule",
      "indices" : [ 90, 104 ]
    }, {
      "text" : "HackMIT",
      "indices" : [ 125, 133 ]
    }, {
      "text" : "conf",
      "indices" : [ 134, 139 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "386739310252150784",
  "text" : "RT @officeresquire: Cookie pirates offer their bounty to teammates while adherents to the #OneCookieRule stare in disbelief. #HackMIT #conf\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "OneCookieRule",
        "indices" : [ 70, 84 ]
      }, {
        "text" : "HackMIT",
        "indices" : [ 105, 113 ]
      }, {
        "text" : "confectionarybullying",
        "indices" : [ 114, 136 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "386728265010143232",
    "text" : "Cookie pirates offer their bounty to teammates while adherents to the #OneCookieRule stare in disbelief. #HackMIT #confectionarybullying",
    "id" : 386728265010143232,
    "created_at" : "2013-10-06 05:42:58 +0000",
    "user" : {
      "name" : "Drew Josephs",
      "screen_name" : "officeresquire",
      "protected" : false,
      "id_str" : "233648614",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2148897502\/image_normal.jpg",
      "id" : 233648614,
      "verified" : false
    }
  },
  "id" : 386739310252150784,
  "created_at" : "2013-10-06 06:26:51 +0000",
  "user" : {
    "name" : "Dibyo Mukherjee",
    "screen_name" : "Dibyo13",
    "protected" : false,
    "id_str" : "21480436",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2692919961\/0a7d701ca39a1c35ee6102255665dafd_normal.jpeg",
    "id" : 21480436,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "HackMIT",
      "screen_name" : "HackMIT",
      "indices" : [ 0, 8 ],
      "id_str" : "1338324476",
      "id" : 1338324476
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "386580331995742208",
  "geo" : { },
  "id_str" : "386605015554473984",
  "in_reply_to_user_id" : 1338324476,
  "text" : "@HackMIT Thanks!",
  "id" : 386605015554473984,
  "in_reply_to_status_id" : 386580331995742208,
  "created_at" : "2013-10-05 21:33:13 +0000",
  "in_reply_to_screen_name" : "HackMIT",
  "in_reply_to_user_id_str" : "1338324476",
  "user" : {
    "name" : "Dibyo Mukherjee",
    "screen_name" : "Dibyo13",
    "protected" : false,
    "id_str" : "21480436",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2692919961\/0a7d701ca39a1c35ee6102255665dafd_normal.jpeg",
    "id" : 21480436,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "HackMIT",
      "screen_name" : "HackMIT",
      "indices" : [ 0, 8 ],
      "id_str" : "1338324476",
      "id" : 1338324476
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "386572575167356928",
  "in_reply_to_user_id" : 1338324476,
  "text" : "@HackMIT Does Amicus have a table somewhere?",
  "id" : 386572575167356928,
  "created_at" : "2013-10-05 19:24:18 +0000",
  "in_reply_to_screen_name" : "HackMIT",
  "in_reply_to_user_id_str" : "1338324476",
  "user" : {
    "name" : "Dibyo Mukherjee",
    "screen_name" : "Dibyo13",
    "protected" : false,
    "id_str" : "21480436",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2692919961\/0a7d701ca39a1c35ee6102255665dafd_normal.jpeg",
    "id" : 21480436,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/foursquare.com\" rel=\"nofollow\"\u003Efoursquare\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 74, 96 ],
      "url" : "http:\/\/t.co\/DpGADecE5X",
      "expanded_url" : "http:\/\/4sq.com\/1cgc1t7",
      "display_url" : "4sq.com\/1cgc1t7"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.358355, -71.094651 ]
  },
  "id_str" : "386474321205821440",
  "text" : "HackMIT (@ MIT Kresge Auditorium (Building W16) for HackMIT w\/ 38 others) http:\/\/t.co\/DpGADecE5X",
  "id" : 386474321205821440,
  "created_at" : "2013-10-05 12:53:53 +0000",
  "user" : {
    "name" : "Dibyo Mukherjee",
    "screen_name" : "Dibyo13",
    "protected" : false,
    "id_str" : "21480436",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2692919961\/0a7d701ca39a1c35ee6102255665dafd_normal.jpeg",
    "id" : 21480436,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "HackMIT",
      "screen_name" : "HackMIT",
      "indices" : [ 13, 21 ],
      "id_str" : "1338324476",
      "id" : 1338324476
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 40.4950462, -80.2469246 ]
  },
  "id_str" : "386276101074714624",
  "text" : "On my way to @HackMIT . So excited!!!",
  "id" : 386276101074714624,
  "created_at" : "2013-10-04 23:46:13 +0000",
  "user" : {
    "name" : "Dibyo Mukherjee",
    "screen_name" : "Dibyo13",
    "protected" : false,
    "id_str" : "21480436",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2692919961\/0a7d701ca39a1c35ee6102255665dafd_normal.jpeg",
    "id" : 21480436,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dave Fontenot",
      "screen_name" : "davefontenot",
      "indices" : [ 3, 16 ],
      "id_str" : "470790728",
      "id" : 470790728
    }, {
      "name" : "HackMIT",
      "screen_name" : "HackMIT",
      "indices" : [ 89, 97 ],
      "id_str" : "1338324476",
      "id" : 1338324476
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "385597965072470016",
  "text" : "RT @davefontenot: Headed to Boston for the first time ever. Couldn't be more excited for @HackMIT this weekend. Retweet if you'll be there!\u2026",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ {
        "name" : "HackMIT",
        "screen_name" : "HackMIT",
        "indices" : [ 71, 79 ],
        "id_str" : "1338324476",
        "id" : 1338324476
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "hackathonseason",
        "indices" : [ 122, 138 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "385448446259261442",
    "text" : "Headed to Boston for the first time ever. Couldn't be more excited for @HackMIT this weekend. Retweet if you'll be there! #hackathonseason",
    "id" : 385448446259261442,
    "created_at" : "2013-10-02 16:57:25 +0000",
    "user" : {
      "name" : "Dave Fontenot",
      "screen_name" : "davefontenot",
      "protected" : false,
      "id_str" : "470790728",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3726491457\/145fe25e632cd45d3f3c0e93c277221a_normal.jpeg",
      "id" : 470790728,
      "verified" : false
    }
  },
  "id" : 385597965072470016,
  "created_at" : "2013-10-03 02:51:33 +0000",
  "user" : {
    "name" : "Dibyo Mukherjee",
    "screen_name" : "Dibyo13",
    "protected" : false,
    "id_str" : "21480436",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2692919961\/0a7d701ca39a1c35ee6102255665dafd_normal.jpeg",
    "id" : 21480436,
    "verified" : false
  }
} ]