Grailbird.data.tweets_2010_12 = 
 [ {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chetan Bhagat",
      "screen_name" : "chetan_bhagat",
      "indices" : [ 3, 17 ],
      "id_str" : "44588485",
      "id" : 44588485
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "12945577696301056",
  "text" : "RT @chetan_bhagat: If you are classy, it does not mean you have to look down and sneer at the massy. For that's not classy at all.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.ubertwitter.com\/bb\/download.php\" rel=\"nofollow\"\u003E\u00DCberSocialOrig\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "12822348415635456",
    "text" : "If you are classy, it does not mean you have to look down and sneer at the massy. For that's not classy at all.",
    "id" : 12822348415635456,
    "created_at" : "2010-12-09 10:54:20 +0000",
    "user" : {
      "name" : "Chetan Bhagat",
      "screen_name" : "chetan_bhagat",
      "protected" : false,
      "id_str" : "44588485",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3291106775\/366fcdbc011a8383610e6973d22cc884_normal.jpeg",
      "id" : 44588485,
      "verified" : true
    }
  },
  "id" : 12945577696301056,
  "created_at" : "2010-12-09 19:04:00 +0000",
  "user" : {
    "name" : "Dibyo Mukherjee",
    "screen_name" : "Dibyo13",
    "protected" : false,
    "id_str" : "21480436",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2692919961\/0a7d701ca39a1c35ee6102255665dafd_normal.jpeg",
    "id" : 21480436,
    "verified" : false
  }
} ]