Grailbird.data.tweets_2012_07 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "230409753287860224",
  "text" : "Building Wars all day long!",
  "id" : 230409753287860224,
  "created_at" : "2012-07-31 21:09:00 +0000",
  "user" : {
    "name" : "Dibyo Mukherjee",
    "screen_name" : "Dibyo13",
    "protected" : false,
    "id_str" : "21480436",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2692919961\/0a7d701ca39a1c35ee6102255665dafd_normal.jpeg",
    "id" : 21480436,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Evaristo",
      "screen_name" : "NsaRisto",
      "indices" : [ 3, 12 ],
      "id_str" : "424503034",
      "id" : 424503034
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "collaboration",
      "indices" : [ 98, 112 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "229032889617092608",
  "text" : "RT @NsaRisto: Haha Chris Brown singing don't wake me up. Next song Katy Perry singing wide awake. #collaboration",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "collaboration",
        "indices" : [ 84, 98 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "228979292195926017",
    "text" : "Haha Chris Brown singing don't wake me up. Next song Katy Perry singing wide awake. #collaboration",
    "id" : 228979292195926017,
    "created_at" : "2012-07-27 22:24:52 +0000",
    "user" : {
      "name" : "Evaristo",
      "screen_name" : "NsaRisto",
      "protected" : false,
      "id_str" : "424503034",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3620415891\/b052dab3d61a1b5dcf5f04265770a407_normal.jpeg",
      "id" : 424503034,
      "verified" : false
    }
  },
  "id" : 229032889617092608,
  "created_at" : "2012-07-28 01:57:50 +0000",
  "user" : {
    "name" : "Dibyo Mukherjee",
    "screen_name" : "Dibyo13",
    "protected" : false,
    "id_str" : "21480436",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2692919961\/0a7d701ca39a1c35ee6102255665dafd_normal.jpeg",
    "id" : 21480436,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Salman Rushdie",
      "screen_name" : "SalmanRushdie",
      "indices" : [ 3, 17 ],
      "id_str" : "373416209",
      "id" : 373416209
    }, {
      "name" : "Eddie",
      "screen_name" : "NBABallerHoller",
      "indices" : [ 74, 90 ],
      "id_str" : "164044677",
      "id" : 164044677
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "227594006912188416",
  "text" : "RT @SalmanRushdie: If by some bizarre chance there turns out to be a god, @NBABallerHoller, I'm willing to bet he's an atheist too.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Eddie",
        "screen_name" : "NBABallerHoller",
        "indices" : [ 55, 71 ],
        "id_str" : "164044677",
        "id" : 164044677
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "227573347947520000",
    "geo" : { },
    "id_str" : "227573738206535680",
    "in_reply_to_user_id" : 164044677,
    "text" : "If by some bizarre chance there turns out to be a god, @NBABallerHoller, I'm willing to bet he's an atheist too.",
    "id" : 227573738206535680,
    "in_reply_to_status_id" : 227573347947520000,
    "created_at" : "2012-07-24 01:19:41 +0000",
    "in_reply_to_screen_name" : "NBABallerHoller",
    "in_reply_to_user_id_str" : "164044677",
    "user" : {
      "name" : "Salman Rushdie",
      "screen_name" : "SalmanRushdie",
      "protected" : false,
      "id_str" : "373416209",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1655254469\/photo-2_normal.JPG",
      "id" : 373416209,
      "verified" : true
    }
  },
  "id" : 227594006912188416,
  "created_at" : "2012-07-24 02:40:14 +0000",
  "user" : {
    "name" : "Dibyo Mukherjee",
    "screen_name" : "Dibyo13",
    "protected" : false,
    "id_str" : "21480436",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2692919961\/0a7d701ca39a1c35ee6102255665dafd_normal.jpeg",
    "id" : 21480436,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Roma Panganiban",
      "screen_name" : "romapancake",
      "indices" : [ 3, 15 ],
      "id_str" : "62713836",
      "id" : 62713836
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "227593758357721088",
  "text" : "RT @romapancake: People who don't understand the difference between Reply and Reply All should be banned from email forever.",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "227584405315665920",
    "text" : "People who don't understand the difference between Reply and Reply All should be banned from email forever.",
    "id" : 227584405315665920,
    "created_at" : "2012-07-24 02:02:05 +0000",
    "user" : {
      "name" : "Roma Panganiban",
      "screen_name" : "romapancake",
      "protected" : false,
      "id_str" : "62713836",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2855495765\/19b91ca768206e3a728051adf7fc4e9b_normal.jpeg",
      "id" : 62713836,
      "verified" : false
    }
  },
  "id" : 227593758357721088,
  "created_at" : "2012-07-24 02:39:15 +0000",
  "user" : {
    "name" : "Dibyo Mukherjee",
    "screen_name" : "Dibyo13",
    "protected" : false,
    "id_str" : "21480436",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2692919961\/0a7d701ca39a1c35ee6102255665dafd_normal.jpeg",
    "id" : 21480436,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Serafina Lanna",
      "screen_name" : "fina_land",
      "indices" : [ 3, 13 ],
      "id_str" : "612259269",
      "id" : 612259269
    }, {
      "name" : "Zach Restelli",
      "screen_name" : "zachtyler",
      "indices" : [ 65, 75 ],
      "id_str" : "18680437",
      "id" : 18680437
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FreedomTrail",
      "indices" : [ 76, 89 ]
    }, {
      "text" : "Bostonproblems",
      "indices" : [ 90, 105 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "225778399665344513",
  "text" : "RT @fina_land: Paul Revere's cover charge is way too high - Zach @zachtyler #FreedomTrail #Bostonproblems",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Zach Restelli",
        "screen_name" : "zachtyler",
        "indices" : [ 50, 60 ],
        "id_str" : "18680437",
        "id" : 18680437
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "FreedomTrail",
        "indices" : [ 61, 74 ]
      }, {
        "text" : "Bostonproblems",
        "indices" : [ 75, 90 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "225776961916649473",
    "text" : "Paul Revere's cover charge is way too high - Zach @zachtyler #FreedomTrail #Bostonproblems",
    "id" : 225776961916649473,
    "created_at" : "2012-07-19 02:19:57 +0000",
    "user" : {
      "name" : "Serafina Lanna",
      "screen_name" : "fina_land",
      "protected" : false,
      "id_str" : "612259269",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2321135419\/Picture_of_me_1_normal.png",
      "id" : 612259269,
      "verified" : false
    }
  },
  "id" : 225778399665344513,
  "created_at" : "2012-07-19 02:25:39 +0000",
  "user" : {
    "name" : "Dibyo Mukherjee",
    "screen_name" : "Dibyo13",
    "protected" : false,
    "id_str" : "21480436",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2692919961\/0a7d701ca39a1c35ee6102255665dafd_normal.jpeg",
    "id" : 21480436,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "222320672079216640",
  "text" : "Day 1 at Big Blue...",
  "id" : 222320672079216640,
  "created_at" : "2012-07-09 13:25:53 +0000",
  "user" : {
    "name" : "Dibyo Mukherjee",
    "screen_name" : "Dibyo13",
    "protected" : false,
    "id_str" : "21480436",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2692919961\/0a7d701ca39a1c35ee6102255665dafd_normal.jpeg",
    "id" : 21480436,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gregory Kapfhammer",
      "screen_name" : "GregKapfhammer",
      "indices" : [ 3, 18 ],
      "id_str" : "361673478",
      "id" : 361673478
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "219851590377545729",
  "text" : "RT @GregKapfhammer: Yes, you can use less watts on your laptop! Here are some useful tips for saving power in recent versions of Ubuntu: ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twmode.sf.net\/\" rel=\"nofollow\"\u003Etwmode\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 117, 137 ],
        "url" : "http:\/\/t.co\/GQu0WBeI",
        "expanded_url" : "http:\/\/is.gd\/5rnG9c",
        "display_url" : "is.gd\/5rnG9c"
      } ]
    },
    "geo" : { },
    "id_str" : "219832244695605248",
    "text" : "Yes, you can use less watts on your laptop! Here are some useful tips for saving power in recent versions of Ubuntu: http:\/\/t.co\/GQu0WBeI",
    "id" : 219832244695605248,
    "created_at" : "2012-07-02 16:37:46 +0000",
    "user" : {
      "name" : "Gregory Kapfhammer",
      "screen_name" : "GregKapfhammer",
      "protected" : false,
      "id_str" : "361673478",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2284981120\/wan4u9fthmpvgug9khsc_normal.jpeg",
      "id" : 361673478,
      "verified" : false
    }
  },
  "id" : 219851590377545729,
  "created_at" : "2012-07-02 17:54:38 +0000",
  "user" : {
    "name" : "Dibyo Mukherjee",
    "screen_name" : "Dibyo13",
    "protected" : false,
    "id_str" : "21480436",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2692919961\/0a7d701ca39a1c35ee6102255665dafd_normal.jpeg",
    "id" : 21480436,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Serafina Lanna",
      "screen_name" : "fina_land",
      "indices" : [ 0, 10 ],
      "id_str" : "612259269",
      "id" : 612259269
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "219294282840932352",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.141152705, -83.734498795 ]
  },
  "id_str" : "219459070103527425",
  "in_reply_to_user_id" : 612259269,
  "text" : "@fina_land I can send you a selection and then you can choose....did you attend an Indian wedding?",
  "id" : 219459070103527425,
  "in_reply_to_status_id" : 219294282840932352,
  "created_at" : "2012-07-01 15:54:54 +0000",
  "in_reply_to_screen_name" : "fina_land",
  "in_reply_to_user_id_str" : "612259269",
  "user" : {
    "name" : "Dibyo Mukherjee",
    "screen_name" : "Dibyo13",
    "protected" : false,
    "id_str" : "21480436",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2692919961\/0a7d701ca39a1c35ee6102255665dafd_normal.jpeg",
    "id" : 21480436,
    "verified" : false
  }
} ]