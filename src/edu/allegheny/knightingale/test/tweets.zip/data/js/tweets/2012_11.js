Grailbird.data.tweets_2012_11 = 
 [ {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "s.",
      "screen_name" : "shaanlu",
      "indices" : [ 0, 8 ],
      "id_str" : "359798875",
      "id" : 359798875
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "271677742217564160",
  "geo" : { },
  "id_str" : "271699340400160769",
  "in_reply_to_user_id" : 359798875,
  "text" : "@shaanlu sounds delicious!",
  "id" : 271699340400160769,
  "in_reply_to_status_id" : 271677742217564160,
  "created_at" : "2012-11-22 19:39:05 +0000",
  "in_reply_to_screen_name" : "shaanlu",
  "in_reply_to_user_id_str" : "359798875",
  "user" : {
    "name" : "Dibyo Mukherjee",
    "screen_name" : "Dibyo13",
    "protected" : false,
    "id_str" : "21480436",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2692919961\/0a7d701ca39a1c35ee6102255665dafd_normal.jpeg",
    "id" : 21480436,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/Dibyo13\/status\/264118104815181825\/photo\/1",
      "indices" : [ 0, 20 ],
      "url" : "http:\/\/t.co\/JOFkYfM3",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/A6pWBFiCIAQbUde.jpg",
      "id_str" : "264118104819376132",
      "id" : 264118104819376132,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A6pWBFiCIAQbUde.jpg",
      "sizes" : [ {
        "h" : 1944,
        "resize" : "fit",
        "w" : 2592
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/JOFkYfM3"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 9.936521, -84.0755098 ]
  },
  "id_str" : "264118104815181825",
  "text" : "http:\/\/t.co\/JOFkYfM3",
  "id" : 264118104815181825,
  "created_at" : "2012-11-01 21:33:59 +0000",
  "user" : {
    "name" : "Dibyo Mukherjee",
    "screen_name" : "Dibyo13",
    "protected" : false,
    "id_str" : "21480436",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2692919961\/0a7d701ca39a1c35ee6102255665dafd_normal.jpeg",
    "id" : 21480436,
    "verified" : false
  }
} ]