Grailbird.data.tweets_2010_06 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/www.snaptu.com\" rel=\"nofollow\"\u003ESnaptu\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amitabh Bachchan",
      "screen_name" : "SrBachchan",
      "indices" : [ 3, 14 ],
      "id_str" : "145125358",
      "id" : 145125358
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "17479390246",
  "text" : "RT @SrBachchan: T44 -\"Ridicule is the tribute paid to the genius by the mediocrities\" O.W. Mediocre s you have been warned !!",
  "id" : 17479390246,
  "created_at" : "2010-07-01 00:00:00 +0000",
  "user" : {
    "name" : "Dibyo Mukherjee",
    "screen_name" : "Dibyo13",
    "protected" : false,
    "id_str" : "21480436",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2692919961\/0a7d701ca39a1c35ee6102255665dafd_normal.jpeg",
    "id" : 21480436,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mahesh Bhatt",
      "screen_name" : "MaheshNBhatt",
      "indices" : [ 3, 16 ],
      "id_str" : "53556894",
      "id" : 53556894
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "17322140732",
  "text" : "RT @MaheshNBhatt: Random thoughts: A man is known by the company he avoids.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/ubertwitter.com\" rel=\"nofollow\"\u003EUberTwitter\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "17251817189",
    "text" : "Random thoughts: A man is known by the company he avoids.",
    "id" : 17251817189,
    "created_at" : "2010-06-28 13:39:12 +0000",
    "user" : {
      "name" : "Mahesh Bhatt",
      "screen_name" : "MaheshNBhatt",
      "protected" : false,
      "id_str" : "53556894",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3299211056\/23e12b7aaf488f094f3180e6603fe058_normal.jpeg",
      "id" : 53556894,
      "verified" : true
    }
  },
  "id" : 17322140732,
  "created_at" : "2010-06-29 00:00:00 +0000",
  "user" : {
    "name" : "Dibyo Mukherjee",
    "screen_name" : "Dibyo13",
    "protected" : false,
    "id_str" : "21480436",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2692919961\/0a7d701ca39a1c35ee6102255665dafd_normal.jpeg",
    "id" : 21480436,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "saurabh pandit",
      "screen_name" : "panditsaurabh",
      "indices" : [ 3, 17 ],
      "id_str" : "135479183",
      "id" : 135479183
    }, {
      "name" : "Amitabh Bachchan",
      "screen_name" : "SrBachchan",
      "indices" : [ 19, 30 ],
      "id_str" : "145125358",
      "id" : 145125358
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "17322296981",
  "text" : "RT @panditsaurabh: @SrBachchan Cristiano Ronaldo: - God sent me to earth to\uFEFF show people how to play football. Lionel Messi: -I never se ...",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Amitabh Bachchan",
        "screen_name" : "SrBachchan",
        "indices" : [ 0, 11 ],
        "id_str" : "145125358",
        "id" : 145125358
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "17196495450",
    "geo" : { },
    "id_str" : "17250039881",
    "in_reply_to_user_id" : 145125358,
    "text" : "@SrBachchan Cristiano Ronaldo: - God sent me to earth to\uFEFF show people how to play football. Lionel Messi: -I never send anybody!",
    "id" : 17250039881,
    "in_reply_to_status_id" : 17196495450,
    "created_at" : "2010-06-28 13:10:52 +0000",
    "in_reply_to_screen_name" : "SrBachchan",
    "in_reply_to_user_id_str" : "145125358",
    "user" : {
      "name" : "saurabh pandit",
      "screen_name" : "panditsaurabh",
      "protected" : false,
      "id_str" : "135479183",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1317089818\/Photo-0260_normal.jpg",
      "id" : 135479183,
      "verified" : false
    }
  },
  "id" : 17322296981,
  "created_at" : "2010-06-29 00:00:00 +0000",
  "user" : {
    "name" : "Dibyo Mukherjee",
    "screen_name" : "Dibyo13",
    "protected" : false,
    "id_str" : "21480436",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2692919961\/0a7d701ca39a1c35ee6102255665dafd_normal.jpeg",
    "id" : 21480436,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amitabh Bachchan",
      "screen_name" : "SrBachchan",
      "indices" : [ 3, 14 ],
      "id_str" : "145125358",
      "id" : 145125358
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "17116917485",
  "text" : "RT @SrBachchan: T40 -The right to be heard, does not necessarily include the right to be taken seriously ..",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "17084712363",
    "text" : "T40 -The right to be heard, does not necessarily include the right to be taken seriously ..",
    "id" : 17084712363,
    "created_at" : "2010-06-26 11:08:58 +0000",
    "user" : {
      "name" : "Amitabh Bachchan",
      "screen_name" : "SrBachchan",
      "protected" : false,
      "id_str" : "145125358",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2227330575\/Amitji_normal.png",
      "id" : 145125358,
      "verified" : true
    }
  },
  "id" : 17116917485,
  "created_at" : "2010-06-26 00:00:00 +0000",
  "user" : {
    "name" : "Dibyo Mukherjee",
    "screen_name" : "Dibyo13",
    "protected" : false,
    "id_str" : "21480436",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2692919961\/0a7d701ca39a1c35ee6102255665dafd_normal.jpeg",
    "id" : 21480436,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PRIYANKA ",
      "screen_name" : "priyankachopra",
      "indices" : [ 3, 18 ],
      "id_str" : "18681139",
      "id" : 18681139
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "16951952306",
  "text" : "RT @priyankachopra: \"Trying to make someone fall in love with you is about as pointless as trying to control who you fall in love with.\" ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Reema Mehta",
        "screen_name" : "Reemamehta",
        "indices" : [ 121, 132 ],
        "id_str" : "135209135",
        "id" : 135209135
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "16947496939",
    "text" : "\"Trying to make someone fall in love with you is about as pointless as trying to control who you fall in love with.\"(via @Reemamehta)love it",
    "id" : 16947496939,
    "created_at" : "2010-06-24 17:47:15 +0000",
    "user" : {
      "name" : "PRIYANKA ",
      "screen_name" : "priyankachopra",
      "protected" : false,
      "id_str" : "18681139",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000107830642\/7bdff7c6388f8d0b77737460d520792e_normal.jpeg",
      "id" : 18681139,
      "verified" : true
    }
  },
  "id" : 16951952306,
  "created_at" : "2010-06-24 00:00:00 +0000",
  "user" : {
    "name" : "Dibyo Mukherjee",
    "screen_name" : "Dibyo13",
    "protected" : false,
    "id_str" : "21480436",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2692919961\/0a7d701ca39a1c35ee6102255665dafd_normal.jpeg",
    "id" : 21480436,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "iyaz ",
      "screen_name" : "iyaz_ahamed",
      "indices" : [ 3, 15 ],
      "id_str" : "147059392",
      "id" : 147059392
    }, {
      "name" : "Amitabh Bachchan",
      "screen_name" : "SrBachchan",
      "indices" : [ 17, 28 ],
      "id_str" : "145125358",
      "id" : 145125358
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "16802296327",
  "text" : "RT @iyaz_ahamed: @SrBachchan sir, the reason there are so few who talk well in public is that there are so few who think in private.. To ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/blackberry.com\/twitter\" rel=\"nofollow\"\u003ETwitter for BlackBerry\u00AE\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Amitabh Bachchan",
        "screen_name" : "SrBachchan",
        "indices" : [ 0, 11 ],
        "id_str" : "145125358",
        "id" : 145125358
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "16798695540",
    "geo" : { },
    "id_str" : "16799321118",
    "in_reply_to_user_id" : 145125358,
    "text" : "@SrBachchan sir, the reason there are so few who talk well in public is that there are so few who think in private.. To twit iyaz",
    "id" : 16799321118,
    "in_reply_to_status_id" : 16798695540,
    "created_at" : "2010-06-22 21:19:12 +0000",
    "in_reply_to_screen_name" : "SrBachchan",
    "in_reply_to_user_id_str" : "145125358",
    "user" : {
      "name" : "iyaz ",
      "screen_name" : "iyaz_ahamed",
      "protected" : false,
      "id_str" : "147059392",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1168007209\/IMG00103-20091226-1611.jpg_normal.rem",
      "id" : 147059392,
      "verified" : false
    }
  },
  "id" : 16802296327,
  "created_at" : "2010-06-22 00:00:00 +0000",
  "user" : {
    "name" : "Dibyo Mukherjee",
    "screen_name" : "Dibyo13",
    "protected" : false,
    "id_str" : "21480436",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2692919961\/0a7d701ca39a1c35ee6102255665dafd_normal.jpeg",
    "id" : 21480436,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amitabh Bachchan",
      "screen_name" : "SrBachchan",
      "indices" : [ 17, 28 ],
      "id_str" : "145125358",
      "id" : 145125358
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "16627103155",
  "text" : "RT @Nanipopping: @SrBachchan A dialogue from a Southern Film say it in the same accent \" I will hit you so hard even Google will not be  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/blackberry.com\/twitter\" rel=\"nofollow\"\u003ETwitter for BlackBerry\u00AE\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Amitabh Bachchan",
        "screen_name" : "SrBachchan",
        "indices" : [ 0, 11 ],
        "id_str" : "145125358",
        "id" : 145125358
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "16604548359",
    "geo" : { },
    "id_str" : "16608181656",
    "in_reply_to_user_id" : 145125358,
    "text" : "@SrBachchan A dialogue from a Southern Film say it in the same accent \" I will hit you so hard even Google will not be able to find you\"",
    "id" : 16608181656,
    "in_reply_to_status_id" : 16604548359,
    "created_at" : "2010-06-20 10:22:03 +0000",
    "in_reply_to_screen_name" : "SrBachchan",
    "in_reply_to_user_id_str" : "145125358",
    "user" : {
      "name" : "Vivek Krishnani",
      "screen_name" : "vivekkrishnani",
      "protected" : false,
      "id_str" : "44849570",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1292624404\/Hugh_and_me1_normal.jpg",
      "id" : 44849570,
      "verified" : false
    }
  },
  "id" : 16627103155,
  "created_at" : "2010-06-20 00:00:00 +0000",
  "user" : {
    "name" : "Dibyo Mukherjee",
    "screen_name" : "Dibyo13",
    "protected" : false,
    "id_str" : "21480436",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2692919961\/0a7d701ca39a1c35ee6102255665dafd_normal.jpeg",
    "id" : 21480436,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amitabh Bachchan",
      "screen_name" : "SrBachchan",
      "indices" : [ 3, 14 ],
      "id_str" : "145125358",
      "id" : 145125358
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "16327788787",
  "text" : "RT @SrBachchan: T30 -'Fashion is a form of ugliness so intolerable we have to change it every six months'... ha ha , so true.. and three ...",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "16299981083",
    "text" : "T30 -'Fashion is a form of ugliness so intolerable we have to change it every six months'... ha ha , so true.. and three people decide it ..",
    "id" : 16299981083,
    "created_at" : "2010-06-16 11:43:45 +0000",
    "user" : {
      "name" : "Amitabh Bachchan",
      "screen_name" : "SrBachchan",
      "protected" : false,
      "id_str" : "145125358",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2227330575\/Amitji_normal.png",
      "id" : 145125358,
      "verified" : true
    }
  },
  "id" : 16327788787,
  "created_at" : "2010-06-16 00:00:00 +0000",
  "user" : {
    "name" : "Dibyo Mukherjee",
    "screen_name" : "Dibyo13",
    "protected" : false,
    "id_str" : "21480436",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2692919961\/0a7d701ca39a1c35ee6102255665dafd_normal.jpeg",
    "id" : 21480436,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.snaptu.com\/a\/twitter\" rel=\"nofollow\"\u003ESnaptu\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Abhishek Bachchan",
      "screen_name" : "juniorbachchan",
      "indices" : [ 3, 18 ],
      "id_str" : "87170183",
      "id" : 87170183
    }, {
      "name" : "Amitabh Bachchan",
      "screen_name" : "SrBachchan",
      "indices" : [ 23, 34 ],
      "id_str" : "145125358",
      "id" : 145125358
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "15938747691",
  "text" : "RT @juniorbachchan: RT @SrBachchan: Do not walk as if you rule the world ; walk as if you do not care who rules the world ! Now, thats attit",
  "id" : 15938747691,
  "created_at" : "2010-06-11 00:00:00 +0000",
  "user" : {
    "name" : "Dibyo Mukherjee",
    "screen_name" : "Dibyo13",
    "protected" : false,
    "id_str" : "21480436",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2692919961\/0a7d701ca39a1c35ee6102255665dafd_normal.jpeg",
    "id" : 21480436,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003Emobile web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "OMG Facts",
      "screen_name" : "OMGFacts",
      "indices" : [ 3, 12 ],
      "id_str" : "77888423",
      "id" : 77888423
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "15233068890",
  "text" : "RT @OMGFacts: At exactly 06 mins and 07 seconds after 5 o'clock on Aug 9th 2010, it will be 05:06:07 08\/09\/10. This won't happen again u ...",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "15176993798",
    "text" : "At exactly 06 mins and 07 seconds after 5 o'clock on Aug 9th 2010, it will be 05:06:07 08\/09\/10. This won't happen again until the year 3010",
    "id" : 15176993798,
    "created_at" : "2010-06-01 13:16:22 +0000",
    "user" : {
      "name" : "OMG Facts",
      "screen_name" : "OMGFacts",
      "protected" : false,
      "id_str" : "77888423",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3056337530\/0ce45de7704f4c20cd9b2ea9033a288e_normal.png",
      "id" : 77888423,
      "verified" : false
    }
  },
  "id" : 15233068890,
  "created_at" : "2010-06-02 00:00:00 +0000",
  "user" : {
    "name" : "Dibyo Mukherjee",
    "screen_name" : "Dibyo13",
    "protected" : false,
    "id_str" : "21480436",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2692919961\/0a7d701ca39a1c35ee6102255665dafd_normal.jpeg",
    "id" : 21480436,
    "verified" : false
  }
} ]