Grailbird.data.tweets_2011_07 = 
 [ {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "   VISHAL",
      "screen_name" : "V1SH4L",
      "indices" : [ 3, 10 ],
      "id_str" : "615208988",
      "id" : 615208988
    }, {
      "name" : "Punit Malhotra",
      "screen_name" : "punitdmalhotra",
      "indices" : [ 15, 30 ],
      "id_str" : "51690631",
      "id" : 51690631
    }, {
      "name" : "Farhan Akhtar",
      "screen_name" : "FarOutAkhtar",
      "indices" : [ 35, 48 ],
      "id_str" : "97865628",
      "id" : 97865628
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "95780025374216192",
  "text" : "RT @V1SH4L: RT @punitdmalhotra: RT @FarOutAkhtar: \"When you go home, tell them of us and say, for your tomorrow, we gave our ... http:\/\/ ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/ubersocial.com\" rel=\"nofollow\"\u003EUberSocial for BlackBerry\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Punit Malhotra",
        "screen_name" : "punitdmalhotra",
        "indices" : [ 3, 18 ],
        "id_str" : "51690631",
        "id" : 51690631
      }, {
        "name" : "Farhan Akhtar",
        "screen_name" : "FarOutAkhtar",
        "indices" : [ 23, 36 ],
        "id_str" : "97865628",
        "id" : 97865628
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "95771185098403840",
    "text" : "RT @punitdmalhotra: RT @FarOutAkhtar: \"When you go home, tell them of us and say, for your tomorrow, we gave our ... http:\/\/tmi.me\/dwFhh",
    "id" : 95771185098403840,
    "created_at" : "2011-07-26 08:23:24 +0000",
    "user" : {
      "name" : "VISHAL DADLANI",
      "screen_name" : "VishalDadlani",
      "protected" : false,
      "id_str" : "41364508",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000641395764\/01c15941970f3e3a07f7ed26b2cf582e_normal.png",
      "id" : 41364508,
      "verified" : true
    }
  },
  "id" : 95780025374216192,
  "created_at" : "2011-07-26 08:58:32 +0000",
  "user" : {
    "name" : "Dibyo Mukherjee",
    "screen_name" : "Dibyo13",
    "protected" : false,
    "id_str" : "21480436",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2692919961\/0a7d701ca39a1c35ee6102255665dafd_normal.jpeg",
    "id" : 21480436,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Moni Mohsin",
      "screen_name" : "moni_butterfly",
      "indices" : [ 3, 18 ],
      "id_str" : "280098725",
      "id" : 280098725
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "91921067588857856",
  "text" : "RT @moni_butterfly: Janoo says in Mumbai it was 26\/11 and 13\/7. In NY it was 9\/11, in London 7\/7. In Pakistan it is 24\/7.",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "91407314669678593",
    "text" : "Janoo says in Mumbai it was 26\/11 and 13\/7. In NY it was 9\/11, in London 7\/7. In Pakistan it is 24\/7.",
    "id" : 91407314669678593,
    "created_at" : "2011-07-14 07:22:56 +0000",
    "user" : {
      "name" : "Moni Mohsin",
      "screen_name" : "moni_butterfly",
      "protected" : false,
      "id_str" : "280098725",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1331407499\/Moni_Mohsin_photo_normal.JPG",
      "id" : 280098725,
      "verified" : false
    }
  },
  "id" : 91921067588857856,
  "created_at" : "2011-07-15 17:24:24 +0000",
  "user" : {
    "name" : "Dibyo Mukherjee",
    "screen_name" : "Dibyo13",
    "protected" : false,
    "id_str" : "21480436",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2692919961\/0a7d701ca39a1c35ee6102255665dafd_normal.jpeg",
    "id" : 21480436,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "   VISHAL",
      "screen_name" : "V1SH4L",
      "indices" : [ 3, 10 ],
      "id_str" : "615208988",
      "id" : 615208988
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "88195294671552513",
  "text" : "RT @V1SH4L: Ghulam Nabi Idiot.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/ubersocial.com\" rel=\"nofollow\"\u003EUberSocial for BlackBerry\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "88143188040220672",
    "text" : "Ghulam Nabi Idiot.",
    "id" : 88143188040220672,
    "created_at" : "2011-07-05 07:12:28 +0000",
    "user" : {
      "name" : "VISHAL DADLANI",
      "screen_name" : "VishalDadlani",
      "protected" : false,
      "id_str" : "41364508",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000641395764\/01c15941970f3e3a07f7ed26b2cf582e_normal.png",
      "id" : 41364508,
      "verified" : true
    }
  },
  "id" : 88195294671552513,
  "created_at" : "2011-07-05 10:39:31 +0000",
  "user" : {
    "name" : "Dibyo Mukherjee",
    "screen_name" : "Dibyo13",
    "protected" : false,
    "id_str" : "21480436",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2692919961\/0a7d701ca39a1c35ee6102255665dafd_normal.jpeg",
    "id" : 21480436,
    "verified" : false
  }
} ]